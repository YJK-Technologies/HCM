import React, { useState } from "react";
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-autocomplete-editor/dist/main.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';
import { format } from 'date-fns';
import { ToastContainer, toast } from 'react-toastify';
import LoadingScreen from '../Loading';
const config = require('../Apiconfig');

const columnDefs = [
  {
    checkboxSelection: true,
    headerName: "Employee ID",
    field: "EmployeeId",
    editable: false,
  },
  {
    headerName: "First Name",
    field: "first_name",
    // filter: 'agTextColumnFilter',
    editable: false,
  },
  {
    headerName: "Middle Name",
    field: "middle_name",
    // filter: 'agTextColumnFilter',
    editable: false,
  },
  {
    headerName: "Last Name",
    field: "Last_Name",
    // filter: 'agTextColumnFilter',
    editable: false,
  },
  {
    headerName: "Phone Number",
    field: "phone1",
    // filter: 'agTextColumnFilter',
    editable: false,
  },
  {
    headerName: "Email",
    field: "email",
    // filter: 'agTextColumnFilter',
    editable: false,
  },
  {
    headerName: "Academic Name",
    field: "academicName",
    editable: false,
  },
  {
    headerName: "Major",
    field: "major",
    editable: false,
  },
  {
    headerName: "Institution",
    field: "institution",
    editable: false,
  },
  {
    headerName: "Department ID",
    field: "department_id",
    editable: false,
  },
  {
    headerName: "Designation ID",
    field: "designation_id",
    editable: false,
  },
  {
    headerName: "Academic Year",
    field: "academicYear",
    editable: false,
  },
  // {
  //   headerName: "Document",
  //   field: "document",
  //   editable: false,
  //   minWidth: 135,
  //   maxWidth: 200,
  //   cellRenderer: (params) => {
  //       if (params.value) {
  //         const fileURL = `data:application/pdf;base64,${params.value}`;
  //         return (
  //           <iframe 
  //             src={fileURL} 
  //             style={{ width: "50px", height: "50px" }}
  //             title="PDF Preview"
  //           />
  //         );
  //       } else {
  //         return <span>No Document</span>;
  //       }
  //     }
  // },

];

const gridOptions = {
  pagination: true,
  paginationPageSize: 10,
};

export default function AcademicDetailsPopup({ open, handleClose, academicDetails }) {

  const [rowData, setRowData] = useState([]);
  const [EmployeeId, setEmployeeId] = useState("");
  const [AcademicName, setAcademicName] = useState("");
  const [Major, setMajor] = useState("");
  const [Institution, setInstitution] = useState("");
  const [Name, setname] = useState("");
  const [loading, setLoading] = useState(false);

  const [academicYearFrom, setAcademicYearFrom] = useState("");
  const [academicYearTo, setAcademicYearTo] = useState("");





  const handleSearch = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${config.apiBaseUrl}/getAcademicDetailsSearchCretria`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          EmployeeId, academicName: AcademicName, Name, major: Major, institution: Institution,
          academic_year_from: academicYearFrom || null,
          academic_year_to: academicYearTo || null,
          company_code: sessionStorage.getItem("selectedCompanyCode")
        })
      });
      if (response.ok) {
        const searchData = await response.json();

        const updatedData = await Promise.all(
          searchData.map(async (item) => ({
            ...item,
            EmployeeId: item.EmployeeId,
            academicName: item.academicName,
            major: item.major,
            // document: item.document ? arrayBufferToBase64(item.document.data) : null,
            institution: item.institution,
            academicYear: item.academicYear,
            academic_year_from: item.academic_year_from,
            academic_year_to: item.academic_year_to
          }))
        );
        setRowData(updatedData);
        console.log("data fetched successfully")
      } else if (response.status === 404) {
        toast.warning("Data Not found")
        setRowData([]);
        console.log("Data not found");
      } else {
        const errorResponse = await response.json();
        toast.warning(errorResponse.message || "Failed to insert sales data");
      }
    } catch (error) {
      console.error("Error deleting rows:", error);
      toast.error('Error Deleting Data: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClosePopup = () => {
    clearInputs();       // ✅ clear inputs
    setRowData([]);      // ✅ clear grid
    setSelectedRows([]); // ✅ clear selection
    handleClose();       // ✅ close popup
  };

  const handleReload = () => {
    clearInputs();
    setRowData([]);
  };

  const clearInputs = () => {
    setEmployeeId("");
    setname("");                // ✅ Name
    setAcademicName("");
    setMajor("");
    setInstitution("");

    setAcademicYearFrom("");    // ✅ From date
    setAcademicYearTo("");      // ✅ To date
  };

  const [selectedRows, setSelectedRows] = useState([]);

  const handleRowSelected = (event) => {
    setSelectedRows(event.api.getSelectedRows());
  };

  const handleConfirm = () => {
    const selectedData = selectedRows.map(row => ({
      employeeId: row.EmployeeId,
      first_name: row.first_name,
      Department: row.department_id,
      Designation: row.designation_id,
    }));

    academicDetails(selectedData);
    handleClosePopup();
  }

  return (
    <div>
      {open && (
        <div className="modal-overlay">
          {loading && <LoadingScreen />}
          <div className="custom-modal container-fluid Topnav-screen">
            <div className="custom-modal-body">

              <div className="shadow-lg p-1 bg-light main-header-box">
                <div className="header-flex">
                  <h1 className="custom-modal-title">Academic Details Help</h1>

                  <div className="action-wrapper">
                    <div className="action-icon delete" onClick={handleClosePopup}>
                      <span className="tooltip">Close</span>
                      <i className="fa-solid fa-xmark"></i>
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-row shadow-lg p-2 bg-light mt-2 container-form-box">

                <div className="form-block col-md-3">
                  <div className="inputGroup">
                    <input
                      type="text"
                      autoComplete="off"
                      placeholder=" "
                      className="exp-input-field form-control"
                      title="Please Enter the Employee ID"
                      value={EmployeeId}
                      onChange={(e) => setEmployeeId(e.target.value)}
                      // onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                    />
                    <label className="exp-form-labels">Employee ID</label>
                  </div>
                </div>

                <div className="form-block col-md-3">
                  <div className="inputGroup">
                    <input
                      type="text"
                      autoComplete="off"
                      placeholder=" "
                      className="exp-input-field form-control"
                      value={Name}
                      onChange={(e) => setname(e.target.value)}
                      title="Please Enter the Employee Name"
                      // onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                    />
                    <label className="exp-form-labels">Employee Name</label>
                  </div>
                </div>

                <div className="form-block col-md-3">
                  <div className="inputGroup">
                    <input
                      type="text"
                      autoComplete="off"
                      placeholder=" "
                      className="exp-input-field form-control"
                        title="Please Enter the Academic Name"
                      value={AcademicName}
                      onChange={(e) => setAcademicName(e.target.value)}
                      // onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                    />
                    <label className="exp-form-labels">Academic Name</label>
                  </div>
                </div>

                <div className="form-block col-md-3">
                  <div className="inputGroup">
                    <input
                      type="text"
                      autoComplete="off"
                      placeholder=" "
                      className="exp-input-field form-control"
                      title="Please Enter the Major"
                      value={Major}
                      onChange={(e) => setMajor(e.target.value)}
                      // onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                    />
                    <label className="exp-form-labels">Major</label>
                  </div>
                </div>

                <div className="form-block col-md-3">
                  <div className="inputGroup">
                    <input
                      type="text"
                      autoComplete="off"
                      placeholder=" "
                      className="exp-input-field form-control"
                      title="Please Enter the Major"
                      value={Institution}
                      onChange={(e) => setInstitution(e.target.value)}
                      // onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                    />
                    <label className="exp-form-labels">Institution</label>
                  </div>
                </div>

                <div className="form-block col-md-3">
                  <div className="inputGroup">
                    <input
                      id="fdate"
                      className="exp-input-field form-control"
                        title="Please Enter the Academic Year From"
                      type="date"
                      placeholder=" "
                      autoComplete="off"
                      // onChange={(e) => RelationInputChange(relationGroup.relation, index, 'academicYear', e.target.value)}
                      value={academicYearFrom}
                      onChange={(e) => setAcademicYearFrom(e.target.value)}
                    />
                    <label
                      for="add1"
                      className={`exp-form-labels`}
                    >
                      Academic Year From
                    </label>
                  </div>
                </div>

                <div className="form-block col-md-3">
                  <div className="inputGroup">
                    <input
                      id="fdate"
                      className="exp-input-field form-control"
                      title="Please Enter the Academic Year To"
                      type="date"
                      placeholder=" "
                      autoComplete="off"
                      // onChange={(e) => RelationInputChange(relationGroup.relation, index, 'academicYear', e.target.value)}
                      value={academicYearTo}
                      onChange={(e) => setAcademicYearTo(e.target.value)}
                    />
                    <label
                      for="add1"
                      className={`exp-form-labels`}
                    >
                      Academic Year To
                    </label>
                  </div>
                </div>

                <div className="form-block col-12">
                  <div className="search-btn-wrapper">

                    <div className="icon-btn search" onClick={handleSearch}>
                      <span className="tooltip">Search</span>
                      <i className="fa-solid fa-magnifying-glass"></i>
                    </div>

                    <div className="icon-btn reload" onClick={handleReload}>
                      <span className="tooltip">Reload</span>
                      <i className="fa-solid fa-rotate-right"></i>
                    </div>

                    <div className="icon-btn save" onClick={handleConfirm}>
                      <span className="tooltip">Confirm</span>
                      <i className="fa-solid fa-check"></i>
                    </div>

                  </div>
                </div>

              </div>

              <div className="shadow-lg p-3 pb-0 bg-light mt-2 container-form-box">
                <div className="ag-theme-alpine" style={{ height: "400px", width: "100%" }}>
                  <AgGridReact
                    rowData={rowData}
                    columnDefs={columnDefs}
                    rowSelection="single"
                    pagination={true}
                    paginationAutoPageSize={true}
                    gridOptions={gridOptions}
                    onSelectionChanged={handleRowSelected}
                  />
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}