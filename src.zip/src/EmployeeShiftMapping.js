import React, { useState, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import "./App.css";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { showConfirmationToast } from "./ToastConfirmation";
import LoadingScreen from "./Loading";
import TabButtons from "./ESSComponents/Tabs";
import Select from "react-select";
import * as XLSX from "xlsx-js-style";

const config = require("./Apiconfig");

function EmployeeTypeMaster() {
  const [activeTab, setActiveTab] = useState("Employee Shift Mapping");
  const [rowData, setRowData] = useState([]);
  const [gridApi, setGridApi] = useState(null);
  const [gridColumnApi, setGridColumnApi] = useState(null);
  const navigate = useNavigate();
  const [editedData, setEditedData] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [employeeShiftId, setEmployeeShiftId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [selectedEmployeeId, setSelectedEmployeeId] = useState("");
  const [employeeIdDrop, setEmployeeIdDrop] = useState([]);
  const [shiftId, setShiftId] = useState("");
  const [selectedShiftId, setSelectedShiftId] = useState("");
  const [shiftIdDrop, setShiftIdDrop] = useState([]);
  const [shiftTypeId, setShiftTypeId] = useState("");
  const [selectedShiftTypeId, setSelectedShiftTypeId] = useState("");
  const [shiftTypeIdDrop, setShiftTypeIdDrop] = useState([]);
  const [shiftPatternId, setShiftPatternId] = useState("");
  const [selectedShiftPatternId, setSelectedShiftPatternId] = useState("");
  const [shiftPatternIdDrop, setShiftPatternIdDrop] = useState([]);
  const [effectiveFrom, setEffectiveFrom] = useState("");
  const [effectiveTo, setEffectiveTo] = useState("");
  const [status, setStatus] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [statusDrop, setStatusDrop] = useState([]);

  const [employeeShiftIdSc, setEmployeeShiftIdSc] = useState("");
  const [employeeIdSc, setEmployeeIdSc] = useState("");
  const [selectedEmployeeIdSc, setSelectedEmployeeIdSc] = useState("");
  const [employeeIdDropSc, setEmployeeIdDropSc] = useState([]);
  const [shiftIdSc, setShiftIdSc] = useState("");
  const [selectedShiftIdSc, setSelectedShiftIdSc] = useState("");
  const [shiftIdDropSc, setShiftIdDropSc] = useState([]);
  const [shiftTypeIdSc, setShiftTypeIdSc] = useState("");
  const [selectedShiftTypeIdSc, setSelectedShiftTypeIdSc] = useState("");
  const [shiftTypeIdDropSc, setShiftTypeIdDropSc] = useState([]);
  const [shiftPatternIdSc, setShiftPatternIdSc] = useState("");
  const [selectedShiftPatternIdSc, setSelectedShiftPatternIdSc] = useState("");
  const [shiftPatternIdDropSc, setShiftPatternIdDropSc] = useState([]);
  const [effectiveFromSc, setEffectiveFromSc] = useState("");
  const [effectiveToSc, setEffectiveToSc] = useState("");
  const [statusSc, setStatusSc] = useState("");
  const [selectedStatusSc, setSelectedStatusSc] = useState("");
  const [statusDropSc, setStatusDropSc] = useState([]);

  const [employeeIdDropGrid, setEmployeeIdDropGrid] = useState([]);
  const [shiftIdDropGrid, setShiftIdDropGrid] = useState([]);
  const [shiftTypeIdDropGrid, setShiftTypeIdDropGrid] = useState([]);
  const [shiftPatternIdDropGrid, setShiftPatternIdDropGrid] = useState([]);
  const [statusDropGrid, setStatusDropGrid] = useState([]);

  const [isSelectStatus, setIsSelectStatus] = useState(false);
  const [isSelectedShiftId, setIsSelectShiftId] = useState(false);
  const [isSelectedEmployeeId, setIsSelectEmployeeId] = useState(false);
  const [isSelectedShiftTypeId, setIsSelectShiftTypeId] = useState(false);
  const [isSelectedShiftPatternId, setIsSelectShiftPatternId] = useState(false);
  const [isSelectStatusSc, setIsSelectStatusSc] = useState(false);
  const [isSelectedShiftIdSc, setIsSelectShiftIdSc] = useState(false);
  const [isSelectedEmployeeIdSc, setIsSelectEmployeeIdSc] = useState(false);
  const [isSelectedShiftTypeIdSc, setIsSelectShiftTypeIdSc] = useState(false);
  const [isSelectedShiftPatternIdSc, setIsSelectShiftPatternIdSc] =
    useState(false);

  const [selectedAGESTypeSc, setSelectedAGESTypeSc] = useState("");
  const [isSelectedAGESTypeSc, setIsSelectedAGESTypeSc] = useState(false);
  const [AGESTypeSc, setAGESTypeSc] = useState("");
  const [AGESTypesDropSc, setAGESTypesDropSc] = useState([]);

  const [mappedType, setMappedType] = useState("ME");
  const [selectedMappedType, setSelectedMappedType] = useState({
    value: "ME",
    label: "Mapped Employee",
  });
  const [isSelectedMappedType, setIsSelectedMappedType] = useState(false);

  const [createdBy, setCreatedBy] = useState("");
  const [modifiedBy, setModifiedBy] = useState("");
  const [createdDate, setCreatedDate] = useState("");
  const [modifiedDate, setModifiedDate] = useState("");

  //code added by Harish purpose of set user permisssion
  const permissions = JSON.parse(sessionStorage.getItem("permissions")) || {};
  const employeeShiftMappingPermission = permissions
    .filter((permission) => permission.screen_type === "EmployeeShiftMapping")
    .map((permission) => permission.permission_type.toLowerCase());

  const searchClearInputFields = () => {
    setEmployeeShiftIdSc("");
    setSelectedEmployeeIdSc("");
    setEmployeeIdSc("");
    setSelectedShiftIdSc("");
    setShiftIdSc("");
    setSelectedShiftTypeIdSc("");
    setShiftTypeIdSc("");
    setSelectedShiftPatternIdSc("");
    setShiftPatternIdSc("");
    setEffectiveFromSc("");
    setEffectiveToSc("");
    setSelectedStatusSc("");
    setStatusSc("");
  };

  const handleChangeStatus = (selectedStatus) => {
    setSelectedStatus(selectedStatus);
    setStatus(selectedStatus ? selectedStatus.value : "");
  };

  const handleChangeEmployeeId = (selectedEmployeeId) => {
    setSelectedEmployeeId(selectedEmployeeId);
    setEmployeeId(selectedEmployeeId ? selectedEmployeeId.value : "");
  };

  const handleChangeShiftId = (selectedShiftId) => {
    setSelectedShiftId(selectedShiftId);
    setShiftId(selectedShiftId ? selectedShiftId.value : "");
  };

  const handleChangeShiftTypeId = (selectedShiftTypeId) => {
    setSelectedShiftTypeId(selectedShiftTypeId);
    setShiftTypeId(selectedShiftTypeId ? selectedShiftTypeId.value : "");
  };

  const handleChangeShiftPatternId = (selectedShiftPatternId) => {
    setSelectedShiftPatternId(selectedShiftPatternId);
    setShiftPatternId(
      selectedShiftPatternId ? selectedShiftPatternId.value : "",
    );
  };

  const handleChangeStatusSc = (selectedStatusSc) => {
    setSelectedStatusSc(selectedStatusSc);
    setStatusSc(selectedStatusSc ? selectedStatusSc.value : "");
  };

  const handleChangeEmployeeIdSc = (selectedEmployeeIdSc) => {
    setSelectedEmployeeIdSc(selectedEmployeeIdSc);
    setEmployeeIdSc(selectedEmployeeIdSc ? selectedEmployeeIdSc.value : "");
  };

  const handleChangeShiftIdSc = (selectedShiftIdSc) => {
    setSelectedShiftIdSc(selectedShiftIdSc);
    setShiftIdSc(selectedShiftIdSc ? selectedShiftIdSc.value : "");
  };

  const handleChangeShiftTypeIdSc = (selectedShiftTypeIdSc) => {
    setSelectedShiftTypeIdSc(selectedShiftTypeIdSc);
    setShiftTypeIdSc(selectedShiftTypeIdSc ? selectedShiftTypeIdSc.value : "");
  };

  const handleChangeShiftPatternIdSc = (selectedShiftPatternIdSc) => {
    setSelectedShiftPatternIdSc(selectedShiftPatternIdSc);
    setShiftPatternIdSc(
      selectedShiftPatternIdSc ? selectedShiftPatternIdSc.value : "",
    );
  };

  //   const handleChangeAGESTypesSc = (selectedAGESTypeSc) => {
  //     setSelectedAGESTypeSc(selectedAGESTypeSc);
  //     setAGESTypeSc(selectedAGESTypeSc ? selectedAGESTypeSc.value : "");
  //   };

  const filteredOptionStatus = statusDrop.map((option) => ({
    value: option.attributedetails_name,
    label: option.attributedetails_name,
  }));

  //   const filteredOptionEmployeeId = employeeIdDrop.map((option) => ({
  //     value: option.EmployeeId,
  //     label: `${option.EmployeeId}-${option.First_Name}`,
  //   }));

  const filteredOptionEmployeeId = Array.isArray(employeeIdDrop)
    ? employeeIdDrop.map((option) => ({
      value: option.EmployeeId,
      label: `${option.EmployeeId} - ${option.First_Name}`,
    }))
    : [];

  const filteredOptionShiftId = shiftIdDrop.map((option) => ({
    value: option.Shift_ID,
    label: `${option.Shift_ID}-${option.Shift_Name}`,
  }));

  const filteredOptionShiftTypeId = shiftTypeIdDrop.map((option) => ({
    value: option.Shift_Type_ID,
    label: `${option.Shift_Type_ID}-${option.Shift_Type}`,
  }));

  const filteredOptionShiftPatternId = shiftPatternIdDrop.map((option) => ({
    value: option.Pattern_Code,
    label: `${option.Pattern_Code}-${option.Pattern_Name}`,
  }));

  const filteredOptionStatusSc = statusDropSc.map((option) => ({
    value: option.attributedetails_name,
    label: option.attributedetails_name,
  }));

  const filteredOptionEmployeeIdSc = employeeIdDropSc.map((option) => ({
    value: option.EmployeeId,
    label: `${option.EmployeeId}-${option.First_Name}`,
  }));

  const filteredOptionShiftIdSc = shiftIdDropSc.map((option) => ({
    value: option.Shift_ID,
    label: `${option.Shift_ID}-${option.Shift_Name}`,
  }));

  const filteredOptionShiftTypeIdSc = shiftTypeIdDropSc.map((option) => ({
    value: option.Shift_Type_ID,
    label: `${option.Shift_Type_ID}-${option.Shift_Type}`,
  }));

  const filteredOptionShiftPatternIdSc = shiftPatternIdDropSc.map((option) => ({
    value: option.Pattern_Code,
    label: `${option.Pattern_Code}-${option.Pattern_Name}`,
  }));

  //   const filteredOptionAGESTypesSc = Array.isArray(AGESTypesDropSc)
  //     ? AGESTypesDropSc.map((option) => ({
  //         value: option?.attributedetails_name,
  //         label: option?.attributedetails_name,
  //       }))
  //     : [];
  const filteredMappedTypeOptions = [
    {
      value: "ME",
      label: "Mapped Employee",
    },
    {
      value: "NME",
      label: "Not Mapped Employee",
    },
  ];

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");
    fetch(`${config.apiBaseUrl}/status`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((response) => response.json())
      .then((data) => {
        const statusOption = data.map((option) => option.attributedetails_name);
        setStatusDropGrid(statusOption);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const Company_Code = sessionStorage.getItem("selectedCompanyCode");
    fetch(`${config.apiBaseUrl}/ShiftPatternMasterDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ Company_Code }),
    })
      .then((response) => response.json())
      .then((data) => {
        const shiftPatternIdOption = data.map((option) => ({
          value: option.Pattern_Code,
          label: `${option.Pattern_Code} - ${option.Pattern_Name}`,
        }));
        setShiftPatternIdDropGrid(shiftPatternIdOption);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");
    fetch(`${config.apiBaseUrl}/ShiftTypeDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((response) => response.json())
      .then((data) => {
        const shiftTypeIdOption = data.map((option) => ({
          value: option.Shift_Type_ID,
          label: `${option.Shift_Type_ID} - ${option.Shift_Type}`,
        }));
        setShiftTypeIdDropGrid(shiftTypeIdOption);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");
    fetch(`${config.apiBaseUrl}/ShiftMasterDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((response) => response.json())
      .then((data) => {
        const shiftIdOption = data.map((option) => ({
          value: option.Shift_ID,
          label: `${option.Shift_ID} - ${option.Shift_Name}`,
        }));
        setShiftIdDropGrid(shiftIdOption);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");
    fetch(`${config.apiBaseUrl}/getEmployeeId`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((response) => response.json())
      .then((data) => {
        const employeeIdOption = data.map((option) => ({
          value: option.EmployeeId,
          label: `${option.EmployeeId} - ${option.First_Name}`,
        }));
        setEmployeeIdDropGrid(employeeIdOption);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/status`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setStatusDrop(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const Company_Code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/ShiftPatternMasterDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ Company_Code }),
    })
      .then((data) => data.json())
      .then((val) => setShiftPatternIdDrop(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/ShiftTypeDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setShiftTypeIdDrop(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/ShiftMasterDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setShiftIdDrop(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  //   useEffect(() => {
  //     const company_code = sessionStorage.getItem("selectedCompanyCode");

  //     fetch(`${config.apiBaseUrl}/getEmployeeId`, {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify({ company_code }),
  //     })
  //       .then((data) => data.json())
  //       .then((val) => setEmployeeIdDrop(val))
  //       .catch((error) => console.error("Error fetching data:", error));
  //   }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/status`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setStatusDropSc(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/getEmployeeId`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setEmployeeIdDropSc(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/ShiftMasterDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setShiftIdDropSc(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/ShiftTypeDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setShiftTypeIdDropSc(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const Company_Code = sessionStorage.getItem("selectedCompanyCode");

    fetch(`${config.apiBaseUrl}/ShiftPatternMasterDropDown`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ Company_Code }),
    })
      .then((data) => data.json())
      .then((val) => setShiftPatternIdDropSc(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem("selectedCompanyCode");
    fetch(`${config.apiBaseUrl}/getFEM`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ company_code }),
    })
      .then((data) => data.json())
      .then((val) => setAGESTypesDropSc(val))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  const handleSearch = async () => {
    setLoading(true);

    try {
      const Company_Code = sessionStorage.getItem("selectedCompanyCode");

      const response = await fetch(
        `${config.apiBaseUrl}/Employee_shift_mappingSc`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            // Emp_Shift_ID: employeeShiftIdSc,
            Employee_ID: employeeIdSc,
            Shift_Pattern_ID: shiftPatternIdSc,
            Effective_From: effectiveFromSc,
            Effective_To: effectiveToSc,
            Is_Current: statusSc,
            Company_Code,
          }),
        },
      );

      if (response.ok) {
        const searchData = await response.json();
        setRowData(searchData);
        console.log("data fetched successfully");
      } else if (response.status === 404) {
        toast.warning("Data not found");
        setRowData([]);
      } else {
        const errorResponse = await response.json();
        toast.warning(errorResponse.message || "Search failed");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Error fetching data: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleChangeMappedType = async (selectedOption) => {
    setSelectedMappedType(selectedOption);

    const selectedValue = selectedOption?.value || "ME";

    setMappedType(selectedValue);

    // clear employee dropdown selection
    setSelectedEmployeeId(null);

    setEmployeeId("");

    fetchEmployeesByMappedType(selectedValue);
  };

  useEffect(() => {
    fetchEmployeesByMappedType("ME");
  }, []);

  const fetchEmployeesByMappedType = async (type) => {
    try {
      const company_code = sessionStorage.getItem("selectedCompanyCode");

      const response = await fetch(
        `${config.apiBaseUrl}/getMappedEmployeeDropdown`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            company_code,
            MappedType: type,
          }),
        },
      );

      const data = await response.json();

      setEmployeeIdDrop(data);

    } catch (error) {
      console.error("Error fetching employee dropdown:", error);
    }
  };

  const reloadGridData = () => {
    setRowData([]);
    searchClearInputFields();
  };

  const columnDefs = [
    {
      headerName: "Actions",
      field: "actions",
      cellRenderer: (params) => {
        const cellWidth = params.column.getActualWidth();
        const isWideEnough = cellWidth > 20;
        const showIcons = isWideEnough;

        return (
          <div
            className="position-relative d-flex align-items-center"
            style={{ minHeight: "100%", justifyContent: "center" }}
          >
            {showIcons && (
              <>
                <span
                  className="icon mx-2"
                  onClick={() => handleUpdate(params.data, params.node.data)}
                  title="Update"
                  style={{ cursor: "pointer" }}
                >
                  <i className="fa-regular fa-floppy-disk"></i>
                </span>

                <span
                  className="icon mx-2"
                  onClick={() => handleDelete(params.data)}
                  style={{ cursor: "pointer" }}
                >
                  <i className="fa-solid fa-trash"></i>
                </span>
              </>
            )}
          </div>
        );
      },
    },
    {
      headerName: "Employee Shift ID",
      field: "Emp_Shift_ID",
      editable: false,
      cellStyle: { textAlign: "left" },
    },
    {
      headerName: "Employee ID",
      field: "Employee_ID",
      editable: true,
      cellEditor: "agSelectCellEditor",
      cellEditorParams: {
        values: employeeIdDropGrid.map((d) => d.value),
      },
      valueFormatter: (params) => {
        const dept = employeeIdDropGrid.find((d) => d.value === params.value);
        return dept ? dept.label : params.value;
      },
    },
    {
      headerName: "Shift Pattern Code",
      field: "Shift_Pattern_ID",
      editable: true,
      cellEditor: "agSelectCellEditor",
      cellEditorParams: {
        values: shiftPatternIdDropGrid.map((d) => d.value),
      },
      valueFormatter: (params) => {
        const dept = shiftPatternIdDropGrid.find(
          (d) => d.value === params.value,
        );
        return dept ? dept.label : params.value;
      },
    },
    {
      headerName: "Effective From",
      field: "Effective_From",
      editable: true,
      cellStyle: { textAlign: "left" },
    },
    {
      headerName: "Effective To",
      field: "Effective_To",
      editable: true,
      cellStyle: { textAlign: "left" },
    },
    {
      headerName: "Status",
      field: "Is_Current",
      editable: true,
      cellEditor: "agSelectCellEditor",
      cellEditorParams: {
        values: statusDropGrid,
      },
    },
    {
      headerName: "keyfield",
      field: "keyfield",
      editable: true,
      filter: true,
      hide: true,
      sortable: false,
    },
  ];

  const defaultColDef = {
    resizable: true,
    editable: true,
  };

  const tabs = [
    { label: "Shift Master" },
    // { label: "Shift Type Master" },
    { label: "Shift Pattern Master" },
    { label: "Shift Pattern Details" },
    // { label: "Employment Type Master" },
    { label: "Employee Shift Mapping" },
  ];

  const handleTabClick = (tabLabel) => {
    setActiveTab(tabLabel);
    switch (tabLabel) {
      case "Shift Master":
        ShiftMaster();
        break;
      // case "Shift Type Master":
      //     ShiftTypeMaster();
      //     break;
      case "Shift Pattern Master":
        ShiftPatternMaster();
        break;
      case "Shift Pattern Details":
        ShiftPatternDetails();
        break;
      // case "Employment Type Master":
      //     EmploymentTypeMaster();
      //     break;
      case "Employee Shift Mapping":
        EmployeeShiftMapping();
        break;
      default:
        break;
    }
  };

  const ShiftMaster = () => {
    navigate("/ShiftMasterGrid");
  };

  const ShiftTypeMaster = () => {
    navigate("/ShiftTypeMaster");
  };

  const ShiftPatternMaster = () => {
    navigate("/ShiftPatternMaster");
  };

  const ShiftPatternDetails = () => {
    navigate("/ShiftPatternDetails");
  };

  const EmploymentTypeMaster = () => {
    navigate("/EmployeeTypeMaster");
  };

  const EmployeeShiftMapping = () => {
    navigate("/EmployeeShiftMapping");
  };

  const onGridReady = (params) => {
    setGridApi(params.api);
    setGridColumnApi(params.columnApi);
  };

  const onSelectionChanged = () => {
    const selectedNodes = gridApi.getSelectedNodes();
    const selectedData = selectedNodes.map((node) => node.data);
    setSelectedRows(selectedData);
  };

  const onCellValueChanged = (params) => {
    const updatedRowData = [...rowData];
    const rowIndex = updatedRowData.findIndex(
      (row) => row.keyfield === params.data.keyfield,
    );

    if (rowIndex !== -1) {
      updatedRowData[rowIndex][params.colDef.field] = params.newValue;
      setRowData(updatedRowData);

      setEditedData((prevData) => {
        const existingIndex = prevData.findIndex(
          (item) => item.keyfield === params.data.keyfield,
        );

        if (existingIndex !== -1) {
          const updatedEdited = [...prevData];
          updatedEdited[existingIndex] = updatedRowData[rowIndex];
          return updatedEdited;
        } else {
          // Add new edited row
          return [...prevData, updatedRowData[rowIndex]];
        }
      });
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return ""; // Return 'N/A' if the date is missing
    const date = new Date(dateString);

    // Format as DD/MM/YYYY
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date);
  };

  const handleRowClick = (rowData) => {
    setCreatedBy(rowData.created_by);
    setModifiedBy(rowData.modified_by);
    const formattedCreatedDate = formatDate(rowData.created_date);
    const formattedModifiedDate = formatDate(rowData.modified_date);
    setCreatedDate(formattedCreatedDate);
    setModifiedDate(formattedModifiedDate);
  };

  // Handler for when a row is selected
  const onRowSelected = (event) => {
    if (event.node.isSelected()) {
      handleRowClick(event.data);
    }
  };

  const handleSave = async () => {
    if (
      !employeeId ||
      !shiftPatternId ||
      !effectiveFrom ||
      !effectiveTo ||
      !status
    ) {
      toast.warning("Missing Required Fields");
      setError(" ");
      return;
    }
    setLoading(true);

    try {
      const response = await fetch(
        `${config.apiBaseUrl}/Employee_shift_mappingInsert`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            // Emp_Shift_ID: employeeShiftId,
            Employee_ID: employeeId,
            Shift_Pattern_ID: shiftPatternId,
            Effective_From: effectiveFrom,
            Effective_To: effectiveTo,
            Is_Current: status,
            Company_Code: sessionStorage.getItem("selectedCompanyCode"),
            Created_by: sessionStorage.getItem("selectedUserCode"),
          }),
        },
      );

      const data = await response.json();

      if (response.ok) {
        toast.success(data.message || "Data inserted successfully", {
          onClose: () => window.location.reload(),
        });
      } else {
        toast.warning(data.message || "Insert failed");
      }
    } catch (error) {
      console.error("Error inserting data:", error);
      toast.error("Server error");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (rowData) => {
    showConfirmationToast(
      "Are you sure you want to update the selected employee shift mapping data?",
      async () => {
        try {
          setLoading(true);
          const Company_Code = sessionStorage.getItem("selectedCompanyCode");
          const Modified_by = sessionStorage.getItem("selectedUserCode");

          const dataToSend = {
            Employee_shift_mappingData: Array.isArray(rowData)
              ? rowData.map((row) => ({
                ...row,
                Company_Code,
                Modified_by,
              }))
              : [
                {
                  ...rowData,
                  Company_Code,
                  Modified_by,
                },
              ],
          };

          const response = await fetch(
            `${config.apiBaseUrl}/Employee_shift_mappingLoopUpdate`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(dataToSend),
            },
          );

          if (response.ok) {
            toast.success("Employee shift mapping updated successfully", {
              onClose: () => handleSearch(),
            });
          } else {
            const errorResponse = await response.json();
            toast.warning(errorResponse.message || "Update failed");
          }
        } catch (error) {
          console.error("Update error:", error);
          toast.error("Error updating data: " + error.message);
        } finally {
          setLoading(false);
        }
      },
      () => toast.info("Update cancelled"),
    );
  };

  const handleDelete = async (rowData) => {
    showConfirmationToast(
      "Are you sure you want to delete the selected rows?",
      async () => {
        try {
          setLoading(true);

          const Company_Code = sessionStorage.getItem("selectedCompanyCode");
          const Modified_by = sessionStorage.getItem("selectedUserCode");
          const dataToSend = {
            Employee_shift_mappingData: Array.isArray(rowData)
              ? rowData.map((row) => ({
                ...row,
                Company_Code,
                Modified_by,
              }))
              : [
                {
                  ...rowData,
                  Company_Code,
                  Modified_by,
                },
              ],
          };

          const response = await fetch(
            `${config.apiBaseUrl}/Employee_shift_mappingLoopDelete`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(dataToSend),
            },
          );

          if (response.ok) {
            toast.success("Data deleted successfully", {
              onClose: () => handleSearch(),
            });
          } else {
            const errorResponse = await response.json();
            toast.warning(errorResponse.message || "Delete failed");
          }
        } catch (error) {
          console.error("Delete error:", error);
          toast.error("Error deleting data: " + error.message);
        } finally {
          setLoading(false);
        }
      },
      () => {
        toast.info("Delete cancelled");
      },
    );
  };

  const getCSSVariable = (variableName) => {
    return getComputedStyle(document.documentElement)
      .getPropertyValue(variableName)
      .trim();
  };

  const transformRowData = (data) => {
    return data.map((row) => {
      const patternObj = shiftPatternIdDropGrid.find(
        (d) => d.value === row.Shift_Pattern_ID,
      );

      const patternName = patternObj
        ? patternObj.label.split(" - ").slice(1).join(" - ")
        : "";

      const empObj = employeeIdDropGrid.find(
        (d) => d.value === row.Employee_ID,
      );

      const empName = empObj
        ? empObj.label.split(" - ").slice(1).join(" - ")
        : "";

      return {
        "Employee Shift ID": row.Emp_Shift_ID || "",
        "Employee ID": `${row.Employee_ID} - ${empName}` || "",
        "Shift Pattern Code": `${row.Shift_Pattern_ID} - ${patternName}` || "",
        "Effective From": row.Effective_From || "",
        "Effective To": row.Effective_To || "",
        Status: row.Is_Current || "",
      };
    });
  };

  const handleExportToExcel = () => {
    if (!rowData || rowData.length === 0) {
      toast.warning("There is no data to export.");
      return;
    }

    const screenName = "Job Master Search Report";
    const company = sessionStorage.getItem("selectedCompanyName") || "";

    /* ================= THEME COLORS ================= */

    const titleBg = getCSSVariable("--but").replace("#", "");
    const tableHeaderBg = getCSSVariable("--ag-header").replace("#", "");
    const fontColor = getCSSVariable("--font-color").replace("#", "");
    const altRowBg = getCSSVariable("--ag-row").replace("#", "");

    /* ================= HEADER ================= */

    const headerData = [
      [screenName],
      company ? [`Company Name: ${company}`] : [],
      [],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(headerData);

    /* ================= TABLE DATA ================= */

    const transformedData = transformRowData(rowData);

    XLSX.utils.sheet_add_json(worksheet, transformedData, {
      origin: `A${headerData.length + 1}`,
    });

    const range = XLSX.utils.decode_range(worksheet["!ref"]);
    const headerRowIndex = headerData.length;

    /* ================= TITLE STYLE ================= */

    worksheet["A1"].s = {
      font: { bold: true, sz: 16, color: { rgb: "FFFFFF" } },
      fill: { fgColor: { rgb: titleBg } },
      alignment: { horizontal: "center", vertical: "center" },
    };

    worksheet["!merges"] = [
      {
        s: { r: 0, c: 0 },
        e: { r: 0, c: Object.keys(transformedData[0]).length - 1 },
      },
    ];

    /* ================= TABLE HEADER STYLE ================= */

    const totalColumns = Object.keys(transformedData[0]).length;

    for (let C = 0; C < totalColumns; C++) {
      const cell =
        worksheet[XLSX.utils.encode_cell({ r: headerRowIndex, c: C })];

      if (!cell) continue;

      cell.s = {
        font: { bold: true, color: { rgb: "FFFFFF" } },
        fill: { fgColor: { rgb: tableHeaderBg } },
        alignment: { horizontal: "center" },
        border: {
          top: { style: "thin" },
          bottom: { style: "thin" },
          left: { style: "thin" },
          right: { style: "thin" },
        },
      };
    }

    /* ================= TABLE BODY STYLE ================= */

    for (let R = headerRowIndex + 1; R <= range.e.r; R++) {
      for (let C = 0; C < totalColumns; C++) {
        const cell = worksheet[XLSX.utils.encode_cell({ r: R, c: C })];

        if (!cell) continue;

        cell.s = {
          font: { color: { rgb: fontColor } },
          fill: R % 2 === 0 ? { fgColor: { rgb: altRowBg } } : undefined,
          border: {
            top: { style: "thin" },
            bottom: { style: "thin" },
            left: { style: "thin" },
            right: { style: "thin" },
          },
        };
      }
    }

    /* ================= COLUMN WIDTH ================= */

    worksheet["!cols"] = Array(totalColumns).fill({ wch: 22 });

    /* ================= EXPORT ================= */

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Job Master");

    XLSX.writeFile(workbook, "Job_Master_Search_Report.xlsx");
  };

  const handleReloadAdd = () => {
    clearInputsAdd([]);
  };

  const clearInputsAdd = () => {
    setSelectedMappedType('');
    setMappedType('');
    setSelectedEmployeeId('');
    setEmployeeId('');
    setSelectedShiftPatternId('');
    setShiftPatternId('');
    setEffectiveFrom('');
    setEffectiveTo('');
    setSelectedStatus('');
    setStatus('');
  };

  return (
    <div className="container-fluid Topnav-screen">
      <div align="">
        {loading && <LoadingScreen />}
        <ToastContainer position="top-right" className="toast-design" theme="colored" />
        <div className="shadow-lg p-1 bg-light rounded main-header-box">
          <div className="header-flex">
            <h1 className="page-title">Employee Shift Mapping</h1>
            <div className="action-wrapper desktop-actions">
              {['add', 'all permission'].some(permission => employeeShiftMappingPermission.includes(permission)) && (
                <div onClick={handleSave} className="action-icon add">
                  <span className="tooltip">Save</span>
                  <i class="fa-solid fa-floppy-disk"></i>
                </div>
              )}
              <div className="action-icon print" onClick={handleReloadAdd}>
                <span className="tooltip">Reload</span>
                <i className="fa-solid fa-arrow-rotate-right"></i>
              </div>
            </div>

            {/* Mobile Dropdown */}
            <div className="dropdown mobile-actions">
              <button
                className="btn btn-primary dropdown-toggle p-0"
                type="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <i className="fa-solid fa-ellipsis-vertical"></i>
              </button>

              <ul className="dropdown-menu dropdown-menu-end text-center">
                {['add', 'all permission'].some(p => employeeShiftMappingPermission.includes(p)) && (
                  <li>
                    <button className="dropdown-item" onClick={handleSave}>
                      <i className="fa-solid fa-floppy-disk add fs-4"></i>
                    </button>
                  </li>
                )}
                <li>
                  <button className="dropdown-item" onClick={handleReloadAdd}>
                    <i className="fa-solid fa-arrow-rotate-right text-dark fs-4"></i>
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <TabButtons
          tabs={tabs}
          activeTab={activeTab}
          onTabClick={handleTabClick}
        />
        <div className="shadow-lg p-3 bg-light rounded mt-2 container-form-box">
          <div className="row g-3">
            {/* <div className="col-md-2">
                            <div className="inputGroup">
                                <input
                                    id="TimeZone_ID"
                                    class="exp-input-field form-control"
                                    type="number"
                                    placeholder=" "
                                    autoComplete="off"
                                    required
                                    value={employeeShiftId}
                                    onChange={(e) => {
                                        const value = e.target.value;
                                        if (value.length <= 5) {
                                            setEmployeeShiftId(value);
                                        }
                                    }}
                                />
                                <label for="state" className={`exp-form-labels ${error && !employeeShiftId ? "text-danger" : ""}`}>
                                    Employee Shift ID<span className="text-danger">*</span>
                                </label>
                            </div>
                        </div> */}
            <div className="col-md-2">
              <div
                className={`inputGroup selectGroup 
                ${selectedMappedType ? "has-value" : ""} 
                ${isSelectedMappedType ? "is-focused" : ""}`}
              >
                <Select
                  classNamePrefix="react-select"
                  placeholder=""
                  value={selectedMappedType}
                  onChange={handleChangeMappedType}
                  options={filteredMappedTypeOptions}
                  isClearable={false}
                  onFocus={() => setIsSelectedMappedType(true)}
                  onBlur={() => setIsSelectedMappedType(false)}
                />
                <label className="floating-label">Mapped Employee</label>
              </div>
            </div>

            <div className="col-md-2">
              <div
                className={`inputGroup selectGroup 
                ${selectedEmployeeId ? "has-value" : ""} 
                ${isSelectedEmployeeId ? "is-focused" : ""}`}
                title="Please select the Employee ID"
              >
                <Select
                  id="status"
                  isClearable
                  value={selectedEmployeeId}
                  onChange={handleChangeEmployeeId}
                  options={filteredOptionEmployeeId}
                  classNamePrefix="react-select"
                  placeholder=" "
                  onFocus={() => setIsSelectEmployeeId(true)}
                  onBlur={() => setIsSelectEmployeeId(false)}
                />
                <label
                  className={`floating-label ${error && !employeeId ? "text-danger" : ""}`}
                >
                  Employee ID<span className="text-danger">*</span>
                </label>
              </div>
            </div>

            {/* <div className="col-md-2">
                            <div
                                className={`inputGroup selectGroup 
                                    ${selectedShiftId ? "has-value" : ""} 
                                    ${isSelectedShiftId ? "is-focused" : ""}`}
                            >
                                <Select
                                    id="status"
                                    isClearable
                                    value={selectedShiftId}
                                    onChange={handleChangeShiftId}
                                    options={filteredOptionShiftId}
                                    classNamePrefix="react-select"
                                    placeholder=" "
                                    onFocus={() => setIsSelectShiftId(true)}
                                    onBlur={() => setIsSelectShiftId(false)}
                                />
                                <label className={`floating-label ${error && !shiftId ? "text-danger" : ""}`}>Shift ID<span className="text-danger">*</span></label>
                            </div>
                        </div>

                        <div className="col-md-2">
                            <div
                                className={`inputGroup selectGroup 
                                    ${selectedShiftTypeId ? "has-value" : ""} 
                                    ${isSelectedShiftTypeId ? "is-focused" : ""}`}
                            >
                                <Select
                                    id="status"
                                    isClearable
                                    value={selectedShiftTypeId}
                                    onChange={handleChangeShiftTypeId}
                                    options={filteredOptionShiftTypeId}
                                    classNamePrefix="react-select"
                                    placeholder=" "
                                    onFocus={() => setIsSelectShiftTypeId(true)}
                                    onBlur={() => setIsSelectShiftTypeId(false)}
                                />
                                <label className={`floating-label ${error && !shiftTypeId ? "text-danger" : ""}`}>Shift Type ID<span className="text-danger">*</span></label>
                            </div>
                        </div> */}

            <div className="col-md-2">
              <div
                className={`inputGroup selectGroup 
                ${selectedShiftPatternId ? "has-value" : ""} 
                ${isSelectedShiftPatternId ? "is-focused" : ""}`}
              >
                <Select
                  id="status"
                  isClearable
                  value={selectedShiftPatternId}
                  onChange={handleChangeShiftPatternId}
                  options={filteredOptionShiftPatternId}
                  classNamePrefix="react-select"
                  placeholder=" "
                  onFocus={() => setIsSelectShiftPatternId(true)}
                  onBlur={() => setIsSelectShiftPatternId(false)}
                />
                <label
                  className={`floating-label ${error && !shiftPatternId ? "text-danger" : ""}`}
                >
                  Shift Pattern ID<span className="text-danger">*</span>
                </label>
              </div>
            </div>

            <div className="col-md-2">
              <div className="inputGroup">
                <input
                  id="TimeZone_ID"
                  class="exp-input-field form-control"
                  type="date"
                  placeholder=" "
                  autoComplete="off"
                  required
                  // min={new Date().toISOString().split("T")[0]}
                  value={effectiveFrom}
                  onChange={(e) => setEffectiveFrom(e.target.value)}
                />
                <label
                  for="state"
                  className={`exp-form-labels ${error && !effectiveFrom ? "text-danger" : ""}`}
                >
                  Effective From<span className="text-danger">*</span>
                </label>
              </div>
            </div>

            <div className="col-md-2">
              <div className="inputGroup">
                <input
                  id="TimeZone_ID"
                  class="exp-input-field form-control"
                  type="date"
                  placeholder=" "
                  autoComplete="off"
                  required
                  // min={new Date().toISOString().split("T")[0]}
                  value={effectiveTo}
                  onChange={(e) => setEffectiveTo(e.target.value)}
                />
                <label
                  for="state"
                  className={`exp-form-labels ${error && !effectiveTo ? "text-danger" : ""}`}
                >
                  Effective To<span className="text-danger">*</span>
                </label>
              </div>
            </div>

            <div className="col-md-2">
              <div
                className={`inputGroup selectGroup 
                                    ${selectedStatus ? "has-value" : ""} 
                                    ${isSelectStatus ? "is-focused" : ""}`}
              >
                <Select
                  id="status"
                  isClearable
                  value={selectedStatus}
                  onChange={handleChangeStatus}
                  options={filteredOptionStatus}
                  classNamePrefix="react-select"
                  placeholder=" "
                  onFocus={() => setIsSelectStatus(true)}
                  onBlur={() => setIsSelectStatus(false)}
                />
                <label
                  className={`floating-label ${error && !status ? "text-danger" : ""}`}
                >
                  Status<span className="text-danger">*</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="shadow-lg p-3 bg-light rounded mt-2 container-form-box">
          <div className="header-flex">
            <h6 className="">Search Criteria:</h6>
          </div>
          <div className="row g-3">
            {/* <div className="col-md-2">
                            <div className="inputGroup">
                                <input
                                    id="TimeZone_ID"
                                    class="exp-input-field form-control"
                                    type="text"
                                    placeholder=" "
                                    autoComplete="off"
                                    required
                                    value={employeeShiftIdSc}
                                    onChange={(e) => {
                                        const value = e.target.value;
                                        if (value.length <= 5) {
                                            setEmployeeShiftIdSc(value);
                                        }
                                    }}
                                />
                                <label for="state" className={`exp-form-labels`}>
                                    Employee Shift ID
                                </label>
                            </div>
                        </div> */}

            <div className="col-md-2">
              <div
                className={`inputGroup selectGroup 
                                    ${selectedEmployeeIdSc ? "has-value" : ""} 
                                    ${isSelectedEmployeeIdSc ? "is-focused" : ""}`}
              >
                <Select
                  id="status"
                  isClearable
                  value={selectedEmployeeIdSc}
                  onChange={handleChangeEmployeeIdSc}
                  options={filteredOptionEmployeeIdSc}
                  classNamePrefix="react-select"
                  placeholder=" "
                  onFocus={() => setIsSelectEmployeeIdSc(true)}
                  onBlur={() => setIsSelectEmployeeIdSc(false)}
                />
                <label className={`floating-label`}>Employee ID</label>
              </div>
            </div>

            {/* <div className="col-md-2">
                            <div
                                className={`inputGroup selectGroup 
                                    ${selectedShiftIdSc ? "has-value" : ""} 
                                    ${isSelectedShiftIdSc ? "is-focused" : ""}`}
                            >
                                <Select
                                    id="status"
                                    isClearable
                                    value={selectedShiftIdSc}
                                    onChange={handleChangeShiftIdSc}
                                    options={filteredOptionShiftIdSc}
                                    classNamePrefix="react-select"
                                    placeholder=" "
                                    onFocus={() => setIsSelectShiftIdSc(true)}
                                    onBlur={() => setIsSelectShiftIdSc(false)}
                                />
                                <label className={`floating-label`}>Shift ID</label>
                            </div>
                        </div>

                        <div className="col-md-2">
                            <div
                                className={`inputGroup selectGroup 
                                    ${selectedShiftTypeIdSc ? "has-value" : ""} 
                                    ${isSelectedShiftTypeIdSc ? "is-focused" : ""}`}
                            >
                                <Select
                                    id="status"
                                    isClearable
                                    value={selectedShiftTypeIdSc}
                                    onChange={handleChangeShiftTypeIdSc}
                                    options={filteredOptionShiftTypeIdSc}
                                    classNamePrefix="react-select"
                                    placeholder=" "
                                    onFocus={() => setIsSelectShiftTypeIdSc(true)}
                                    onBlur={() => setIsSelectShiftTypeIdSc(false)}
                                />
                                <label className={`floating-label`}>Shift Type ID</label>
                            </div>
                        </div> */}

            <div className="col-md-2">
              <div
                className={`inputGroup selectGroup 
                                    ${selectedShiftPatternIdSc ? "has-value" : ""} 
                                    ${isSelectedShiftPatternIdSc ? "is-focused" : ""}`}
              >
                <Select
                  id="status"
                  isClearable
                  value={selectedShiftPatternIdSc}
                  onChange={handleChangeShiftPatternIdSc}
                  options={filteredOptionShiftPatternIdSc}
                  classNamePrefix="react-select"
                  placeholder=" "
                  onFocus={() => setIsSelectShiftPatternIdSc(true)}
                  onBlur={() => setIsSelectShiftPatternIdSc(false)}
                />
                <label className={`floating-label`}>Shift Pattern ID</label>
              </div>
            </div>

            <div className="col-md-2">
              <div className="inputGroup">
                <input
                  id="TimeZone_ID"
                  class="exp-input-field form-control"
                  type="date"
                  placeholder=" "
                  autoComplete="off"
                  required
                  value={effectiveFromSc}
                  onChange={(e) => setEffectiveFromSc(e.target.value)}
                />
                <label for="state" className={`exp-form-labels`}>
                  Effective From
                </label>
              </div>
            </div>

            <div className="col-md-2">
              <div className="inputGroup">
                <input
                  id="TimeZone_ID"
                  class="exp-input-field form-control"
                  type="date"
                  placeholder=" "
                  autoComplete="off"
                  required
                  value={effectiveToSc}
                  onChange={(e) => setEffectiveToSc(e.target.value)}
                />
                <label for="state" className={`exp-form-labels`}>
                  Effective To
                </label>
              </div>
            </div>

            <div className="col-md-2">
              <div
                className={`inputGroup selectGroup 
                                    ${selectedStatusSc ? "has-value" : ""} 
                                    ${isSelectStatusSc ? "is-focused" : ""}`}
              >
                <Select
                  id="status"
                  isClearable
                  value={selectedStatusSc}
                  onChange={handleChangeStatusSc}
                  options={filteredOptionStatusSc}
                  classNamePrefix="react-select"
                  placeholder=" "
                  onFocus={() => setIsSelectStatusSc(true)}
                  onBlur={() => setIsSelectStatusSc(false)}
                />
                <label className={`floating-label`}>Status</label>
              </div>
            </div>

            <div className="col-12">
              <div className="search-btn-wrapper">
                <div className="icon-btn search" onClick={handleSearch}>
                  <span className="tooltip">Search</span>
                  <i className="fa-solid fa-magnifying-glass"></i>
                </div>

                <div className="icon-btn reload" onClick={reloadGridData}>
                  <span className="tooltip">Reload</span>
                  <i className="fa-solid fa-rotate-right"></i>
                </div>

                <div className="icon-btn excel" onClick={handleExportToExcel}>
                  <span className="tooltip">Excel</span>
                  <i className="fa-solid fa-file-excel"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div
          className="shadow-lg pt-3 pb-3 bg-light rounded mt-2 container-form-box"
          style={{ width: "100%" }}
        >
          <div class="ag-theme-alpine" style={{ height: 450, width: "100%" }}>
            <AgGridReact
              rowData={rowData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              onGridReady={onGridReady}
              onCellValueChanged={onCellValueChanged}
              rowSelection="multiple"
              onSelectionChanged={onSelectionChanged}
              pagination={true}
              paginationAutoPageSize={true}
              onRowSelected={onRowSelected}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default EmployeeTypeMaster;
