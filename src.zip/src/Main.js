  import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom";
import Home from './Home.js';
import Login from "./Login.js";
import { useState, useEffect } from "react";
import Input from "./Input.js";
import Grid from "./Grid.js";
import Topbar from "./Topbar2.js";
import SideBar from "./NewSidebar.js";
import UserGrid from "./user_Grid.js";
import UserInput from "./UserInput.js";
import WarehouseGrid from "./WarehouseGrid.js";
import WareHouseInput from "./WareHouseInput.js";
import RoleInfoGrid from "./RoleInfoGrid.js";
import Role_input from "./RoleInfo_Input.js";
import AttriDetGrid from "./AttriDetGrid.js";
import AttriHdrInput from "./AttriHdrInput.js";
import AttriDetInput from "./AttriDetInput.js";
import IntermediaryGrid from "./IntermediaryHeaderGrid.js";
import IntermediaryHdrInput from "./IntermediaryHeaderInput.js";
import IntermediaryDetailInput from "./IntermediaryDetailrInput.js";
import CompanyMappingGrid from "./CompanyMappingGrid.js";
import UserComMap_input from "./CompanyMappingInput.js";
import UserRoleMapGrid from "./UserRoleMapGrid.js";
import UserRoleInput from "./UserRoleMapInput.js";
import LocInfoGrid from "./LocationInfoGrid.js";
import LocInfoInput from "./LocationInput.js";
import Settings from './Settings.js';
import AccountInformation from "./AccountInformation.js";
import UserScreenMapGrid from "./userscreenmapgrid.js";
import UserScreenInput from "./userscreeninput.js";
import NotFound from './NotFound.js'
import BankAccInput from "./BankAccount.js";
import BankAccGrid from "./BankAccountGrid.js";
import EmployeeInput from "./Employeeinput.js";
import BarcodeGenerator from "./Barcode/BarcodeGenerator.js";
import BarcodeScanner from "./Barcode/BarcodeScanner.js";
import DepartmentInput from "./DepartmentInput.js";
import Department from "./DepartmentGrid.js";
import Desgination from "./DesginationGrid.js";
import DesginationInput from "./DesginationInput.js";
import FinancialYearAccess from "./financialYearAccess.js"
import PrintTemplate from "./PrintTemplate.js";
import NumberSeriesGrid from "./NumberSeriesGrid.js";
import NumberSeriesInput from "./NumberSeriesInput.js";
import ESSDashboard from './ESSDashboard/Dashboard.js'
import EmployeeDashboard from './ESSDashboard/EmployeeDashboard.js'
import EmployeeLoan from './ESSComponents/AddEmployeeInfo.js'
import ESSDailyAtten from './ESSComponents/Payslip.js'
import PayslipReport from "./PayslipReport.js"
import Grade from './ESSComponents/Grade.js'
import EmpLeave from './ESSComponents/EmpLeave.js'
import EmpLoanType from './ESSComponents/EmployeeLoanType.js'
import ESSLoan from './ESSComponents/EmpLoan.js'
import EmpLoan from './ESSComponents/EmpLoan.js'
import Announce from './ESSComponents/Announcement.js'
import HoliDays from "./ESSComponents/Holiday.js";
import WeekOff from "./WeekOff.js";
import FinancialYear from "./ESSComponents/FinancialYear.js";
import EmpProject from './TaskMasters/EmpProject.js';
import DailyTask from './TaskMasters/DailyTask.js';
import EmpProjectinput from './TaskMasters/EmpProjectinput.js';
import DailyTaskInput from './TaskMasters/DailyTaskInput.js';
import ProjectMapping from './TaskMasters/ProjectMapping.js';
import PMSsettings from "./SettingScreenPMS.js";
import OpenTickets from './TaskTransactions/OpeningTickets.js';
import Allocatedproject from './TaskTransactions/Projectscreen.js';
import Login_info from './Task_Reports/TaskHours.js';
import ProjectDetails from './Task_Reports/ProjectProgress.js';
import ProjectChartReport from "./Task_Reports/ProjectChartReport.js";
import CompanyDetails from './ESSComponents/CompanyDetails.js';
import FinanceDet from './ESSComponents/FinanceDet.js';
import BankAccDet from './ESSComponents/BankAccDet.js';
import IdentDoc from './ESSComponents/IdentDoc.js';
import AcademicDet from './ESSComponents/AcademicDet.js';
import Insur from './ESSComponents/Insurance.js';
import Documents from './ESSComponents/Document.js';
import EmployeeBonus from './ESSComponents/EmployeeBonus.js';
import EmpPFCompany from './ESSComponents/EmployeePFCompany.js'
import EmpProfessionalTax from './ESSComponents/EmpProfessionalTax.js'
import EmpTDS from './ESSComponents/EmpTDS.js'
import AddFinancialYearAccess from './AddFInancialYearAccess.js'
import ApplyLeave from './ESSDashboard/ApplyLeave.js'
import CandidateMaster from "./OtherMasters/CandidateMaster.js";
import JobMaster from "./OtherMasters/JobMaster.js";
import InterviewPanel from "./OtherMasters/InterviewPanel.js";
import InterviewPanelMem from "./OtherMasters/InterviewPanelmembers.js";
import InterviewSchedule from "./OtherMasters/InterviewSchedule.js";
import InterviewFeedback from "./OtherMasters/InterviewFeedback.js";
import InterviewDecision from "./OtherMasters/InterviewDecision.js";
import CountryMaster from "./NewCountryMasterGrid.js";
import AddCountryMaster from "./AddCountryMaster.js";
import AddTimeZoneMaster from "./AddTimeZoneMaster.js";
import TimeZoneGrid from "./TimeZoneMaster.js";
import ShiftMasterGrid from "./ShiftMasterGrid.js";
import ShiftTypeMaster from "./ShiftTypeMaster.js";
import ShiftPatternMaster from "./ShiftPatternMaster.js";
import ShiftPatternDetails from "./ShiftPatternDetails.js";
import EmployeeTypeMaster from "./EmployeeTypeMaster.js";
import EmployeeShiftMapping from "./EmployeeShiftMapping.js";
import InterviewScheduleReport from "./InterviewScheduleReport.js";
import InterviewFeedbackReport from "./InterviewFeedbackReport.js";
import CandidateInterviewReport from "./CandidateInterviewReport.js";
import PanelPerformanceReport from "./PanelPerformanceReport.js";
import HiringDecisionReport from "./HiringDecisionReport.js";
import TotalCandidatesApplied from "./TotalCandidatesApplied.js";
import TotalInterviewsScheduled from "./TotalInterviewsScheduled.js";
import InterviewCompletionRate from "./InterviewCompletionRate.js";
import InterviewDashboard from "./InterviewDashboard.js";
import DepartmentDashboard from "./DepartmentDashboard.js";
import ShiftSumRep from "./ShiftSumRep.js";
import VisaRequest from "./EmpRequests/VisaRequest.js"
import TravelRequest from "./EmpRequests/TravelRequest.js"
import LoanRequest from "./EmpRequests/LoanRequest.js"
import LoanStatusHistory from "./EmpRequests/LoanStatusHistory.js"
import LoanApprovals from "./EmpRequests/LoanApproval.js"
import LoanDocuments from "./EmpRequests/LoanDocuments.js"
import LoanPayment from "./EmpRequests/LoanPayment.js"
import LoanSchedule from "./EmpRequests/LoanSchedule.js"
import LoanType from "./EmpRequests/LoanType.js"
import ManualEmployeeInfo from "./ESSComponents/ManualEmployeeInfo.js"
import EmpFamPersonalDetail from "./ESSComponents/EmpFamPersonalDetail.js"
import AcademicDetReq from "./ESSComponents/AcademicDetailsRequest.js"
import LeaveRequest from "./EmpRequests/LeaveRequest.js"
import RequestReport from "./ESSDashboard/RequestReport.js"
import EmpDocumentReq from "./ESSComponents/EmpDocumentReq.js"
import EmpAssetsRequest from "./ESSComponents/EmpAssetsRequest.js"
import LoanSummaryReports from "./LoanSummaryReports.js"
import PendingApprovalsReport from "./PendingApprovalsReport.js"
import LoanDisbursementRepo from "./LoanDisbursementReport.js"
import OverdueLoansReport from "./OverdueLoansReport.js"
import RepaymentScheduleReport from "./RepaymentScheduleReport.js"
import EmployeeAssets from './ESSComponents/EmployeeAssets.js';
import { ToastContainer } from "react-toastify";
import GenerateShift from "./ShiftMaster/GenerateShift.js";
import Assets from "./ESSComponents/Assets.js";
import LoanDashboard from './ESSDashboard/LoanDashboard.js';
import EmployeeCompOff from './ESSDashboard/EmployeeCompOff.js';
import PayrollSettings from './PayrollSettings.js';
import PayrollSettingsAdd from './PayrollSettingsAdd.js';
import PendingAssReqRep from './PendingAssReqRep.js';
import CompOffRequest from './EmpRequests/CompOffRequest.js';
import AssetLifecycleRep from './AssetLifecycleRep.js';
import EmpAssetsReport from './EmpAssetsReport.js';
import AbsentReport from './AttendanceReport/AbsentReport.js';
import LateReport from './AttendanceReport/LateReport.js';
import OvertimeReport from './AttendanceReport/OvertimeReport.js';
import AgesReport from './AgesReport.js';
import ShiftChangeRequest from './EmpRequests/ShiftChangeRequest.js'
import AdminShiftChange from './ShiftMaster/AdminShiftChange.js'

function Main() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [screenTypes, setScreenTypes] = useState(
    JSON.parse(sessionStorage.getItem("screenTypes")) || []
  );

  useEffect(() => {
    const loadPermissions = () => {
      const permissionsJSON = sessionStorage.getItem("permissions");
      if (permissionsJSON) {
        const permissions = JSON.parse(permissionsJSON);
        const screens = permissions.map((permission) =>
          permission.screen_type.replace(/\s+/g, "")
        );
        setScreenTypes(screens);
        sessionStorage.setItem("screenTypes", JSON.stringify(screens));
      }
    };

    loadPermissions();

    window.addEventListener("permissionsUpdated", loadPermissions);
    return () => window.removeEventListener("permissionsUpdated", loadPermissions);
  }, []);

  // console.log('Screen Types:', screenTypes);

  // const screenTypes = Object.keys(permissions);

  // create by pavun on 7 may 2024 use: To block the view page source  brgin
  // useEffect(()=>{
  //   document.addEventListener("contextmenu",handlecontextmenu)
  //   return()=>{
  //     document.removeEventListener("contextmenu",handlecontextmenu)
  //   }
  // },[])

  // const handlecontextmenu=(e)=>{
  //   e.preventDefault()
  //   // alert("right click is disable")
  // }
  // create by pavun on 7 may 2024 use: To block the view page source  End

  // useEffect(() => {
  //   const disableCopy = (e) => e.preventDefault();

  //   document.addEventListener("copy", disableCopy);
  //   document.addEventListener("cut", disableCopy);
  //   document.addEventListener("contextmenu", disableCopy);

  //   return () => {
  //     document.removeEventListener("copy", disableCopy);
  //     document.removeEventListener("cut", disableCopy);
  //     document.removeEventListener("contextmenu", disableCopy);
  //   };
  // }, []);

  // useEffect(() => {
  //   const handleKeyDown = (e) => {
  //     if (
  //       (e.ctrlKey || e.metaKey) &&
  //       ["a", "c", "x", "v"].includes(e.key.toLowerCase())
  //     ) {
  //       e.preventDefault();
  //     }
  //   };

  //   document.addEventListener("keydown", handleKeyDown);
  //   return () => document.removeEventListener("keydown", handleKeyDown);
  // }, []);

  const routes = [
    { path: "/", component: <Home /> },
    { path: "/Login", component: <Login /> },
    { path: "/Settings", component: <Settings /> },
    { path: "/TemplateDesign", component: <PrintTemplate /> },
    { path: "/AddCompany", component: <Input /> },
    { path: "/Company", component: <Grid /> },
    { path: "/AddUser", component: <UserInput /> },
    { path: "/User", component: <UserGrid /> },
    { path: "/Warehouse", component: <WarehouseGrid /> },
    { path: "/AddWarehouse", component: <WareHouseInput /> },
    { path: "/Role", component: <RoleInfoGrid /> },
    { path: "/AddRole", component: <Role_input /> },
    { path: "/Attribute", component: <AttriDetGrid /> },
    { path: "/AddAttributeHeader", component: <AttriHdrInput /> },
    { path: "/AddAttributeDetail", component: <AttriDetInput /> },
    { path: "/Intermediary", component: <IntermediaryGrid /> },
    { path: "/AddIntermedHeader", component: <IntermediaryHdrInput /> },
    { path: "/AddIntermedDetails", component: <IntermediaryDetailInput /> },
    { path: "/CompanyMapping", component: <CompanyMappingGrid /> },
    { path: "/AddCompanyMapping", component: <UserComMap_input /> },
    { path: "/UserRoleMapping", component: <UserRoleMapGrid /> },
    { path: "/AddUserRoleMapping", component: <UserRoleInput /> },
    { path: "/Location", component: <LocInfoGrid /> },
    { path: "/AddLocation", component: <LocInfoInput /> },
    { path: "/UserRights", component: <UserScreenMapGrid /> },
    { path: "/AccountInformation", component: <AccountInformation /> },
    { path: "/AddUserRights", component: <UserScreenInput /> },
    { path: "/NotFound", component: <NotFound /> },
    { path: "/AddBankAccount", component: <BankAccInput /> },
    { path: "/BankAccount", component: <BankAccGrid /> },
    { path: "/EmployeeInputInfo", component: <EmployeeInput /> },
    { path: "/BarcodeGenerator", component: <BarcodeGenerator /> },
    { path: "/BarcodeScanner", component: <BarcodeScanner /> },
    { path: "/AddDepartment", component: <DepartmentInput /> },
    { path: "/Department", component: <Department /> },
    { path: "/DesgiantionInfo", component: <Desgination /> },
    { path: "/AddDesgination", component: <DesginationInput /> },
    { path: "/FinancialYearAccess", component: <FinancialYearAccess /> },
    { path: "/NumberSeries", component: <NumberSeriesGrid /> },
    { path: "/AddNumberSeries", component: <NumberSeriesInput /> },
    { path: "/ESSDashboard", component: <ESSDashboard /> },
    { path: "/EmployeeDashboard", component: <EmployeeDashboard /> },
    { path: "/AddEmployeeInfo", component: <EmployeeLoan /> },
    { path: "/salarypath", component: <ESSDailyAtten mode="salarypath" /> },
    { path: "/PayslipReport", component: <PayslipReport /> },
    { path: "/EmployeeGrade", component: <Grade /> },
    { path: "/EmpLeave", component: <EmpLeave /> },
    { path: "/EmployeeLoan", component: <EmpLoan /> },
    { path: "/PayslipEmpLoanType", component: <EmpLoanType /> },
    { path: "/Announce", component: <Announce /> },
    { path: "/HoliDays", component: <HoliDays /> },
    { path: "/WeekOff", component: <WeekOff /> },
    { path: "/PayslipSalaryDays", component: <FinancialYear /> },
    { path: "/Project", component: <EmpProject /> },
    { path: "/ProjectMapping", component: <ProjectMapping /> },
    { path: "/Task", component: <DailyTask /> },
    { path: "/DailyTaskInput", component: <DailyTaskInput /> },
    { path: "/ESSLoan", component: <ESSLoan /> },
    { path: "/EmpProjectinput", component: <EmpProjectinput /> },
    { path: "/PMSsettings", component: <PMSsettings /> },
    { path: "/OpenTickets", component: <OpenTickets /> },
    { path: "/ProjectDetails", component: <Allocatedproject /> },
    { path: "/TaskHours", component: <Login_info /> },
    { path: "/ProjectProgress", component: < ProjectDetails /> },
    { path: "/ProjectChartReport", component: <ProjectChartReport /> },
    { path: "/CompanyDetails", component: <CompanyDetails /> },
    { path: "/FinanceDet", component: <FinanceDet /> },
    { path: "/BankAccDet", component: <BankAccDet /> },
    { path: "/IdentDoc", component: <IdentDoc /> },
    { path: "/AcademicDet", component: <AcademicDet /> },
    { path: "/Family", component: <Insur /> },
    { path: "/Documents", component: <Documents /> },
    { path: "/PayslipEmpBonus", component: <EmployeeBonus /> },
    { path: "/PFContribution", component: <EmpPFCompany /> },
    { path: "/PayslipEmpProTax", component: <EmpProfessionalTax /> },
    { path: "/PayslipEmpTDS", component: <EmpTDS /> },
    { path: "/AddFYA", component: <AddFinancialYearAccess /> },
    { path: "/ApplyLeave", component: <ApplyLeave /> },
    { path: "/salarypath", component: <ESSDailyAtten mode="salarypath" /> },
    { path: "/CandidateMaster", component: <CandidateMaster /> },
    { path: "/JobMaster", component: <JobMaster /> },
    { path: "/InterviewPanel", component: <InterviewPanel /> },
    { path: "/InterviewPanelMem", component: <InterviewPanelMem /> },
    { path: "/InterviewSchedule", component: <InterviewSchedule /> },
    { path: "/InterviewFeedback", component: <InterviewFeedback /> },
    { path: "/InterviewDecision", component: <InterviewDecision /> },
    { path: "/CountryMaster", component: <CountryMaster /> },
    { path: "/AddCountryMaster", component: <AddCountryMaster /> },
    { path: "/AddTimeZoneMaster", component: <AddTimeZoneMaster /> },
    { path: "/TimeZoneGrid", component: <TimeZoneGrid /> },
    { path: "/ShiftMasterGrid", component: <ShiftMasterGrid /> },
    { path: "/ShiftTypeMaster", component: <ShiftTypeMaster /> },
    { path: "/ShiftPatternMaster", component: <ShiftPatternMaster /> },
    { path: "/ShiftPatternDetails", component: <ShiftPatternDetails /> },
    { path: "/EmployeeTypeMaster", component: <EmployeeTypeMaster /> },
    { path: "/EmployeeShiftMapping", component: <EmployeeShiftMapping /> },
    { path: "/InterviewScheduleRep", component: <InterviewScheduleReport /> },
    { path: "/InterviewFeedbackRep", component: <InterviewFeedbackReport /> },
    { path: "/CandidateInterviewRe", component: <CandidateInterviewReport /> },
    { path: "/PanelPerformanceRepo", component: <PanelPerformanceReport /> },
    { path: "/HiringDecisionReport", component: <HiringDecisionReport /> },
    { path: "/TotalCandidatesAppli", component: <TotalCandidatesApplied /> },
    { path: "/TotalInterviewsSched", component: <TotalInterviewsScheduled /> },
    { path: "/InterviewCompletionR", component: <InterviewCompletionRate /> },
    { path: "/InterviewDashboard", component: <InterviewDashboard /> },
    { path: "/GenerateShift", component: <GenerateShift /> },
    { path: "/DepartmentDashboard", component: <DepartmentDashboard /> },
    { path: "/ShiftSumRep", component: <ShiftSumRep /> },
    { path: "/VisaRequest", component: <VisaRequest /> },
    { path: "/TravelRequest", component: <TravelRequest /> },
    { path: "/LoanRequest", component: <LoanRequest /> },
    { path: "/LoanStatusHistory", component: <LoanStatusHistory /> },
    { path: "/LoanApprovals", component: <LoanApprovals /> },
    { path: "/LoanDocuments", component: <LoanDocuments /> },
    { path: "/LoanPayment", component: <LoanPayment /> },
    { path: "/LoanSchedule", component: <LoanSchedule /> },
    { path: "/LoanType", component: <LoanType /> },
    { path: "/ManualEmployeeInfo", component: <ManualEmployeeInfo /> },
    { path: "/LeaveRequest", component: <LeaveRequest /> },
    { path: "/EmpFamPersonalDetail", component: <EmpFamPersonalDetail /> },
    { path: "/AcademicDetReq", component: <AcademicDetReq /> },
    { path: "/RequestReport", component: <RequestReport /> },
    { path: "/EmpDocumentReq", component: <EmpDocumentReq /> },
    { path: "/EmpAssetsRequest", component: <EmpAssetsRequest /> },
    { path: "/LoanSummaryReports", component: <LoanSummaryReports /> },
    { path: "/PendingApprovalsRepo", component: <PendingApprovalsReport /> },
    { path: "/LoanDisbursementRepo", component: <LoanDisbursementRepo /> },
    { path: "/OverdueLoansReport", component: <OverdueLoansReport /> },
    { path: "/RepaymentScheduleRep", component: <RepaymentScheduleReport /> },
    { path: "/EmployeeAssets", component: <EmployeeAssets /> },
    { path: "/Assets", component: <Assets /> },
    { path: "/LoanDashboard", component: <LoanDashboard /> },
    { path: "/EmployeeCompOff", component: <EmployeeCompOff /> },
    { path: "/PayrollSettings", component: <PayrollSettings /> },
    { path: "/PayrollSettingsAdd", component: <PayrollSettingsAdd /> },
    { path: "/PendingAssReqRep", component: <PendingAssReqRep /> },
    { path: "/CompOffRequest", component: <CompOffRequest /> },
    { path: "/AssetLifecycleRep", component: <AssetLifecycleRep /> },
    { path: "/EmpAssetsReport", component: <EmpAssetsReport /> },
    { path: "/LateReport", component: <LateReport /> },
    { path: "/OvertimeReport", component: <OvertimeReport /> },
    { path: "/AbsentReport", component: <AbsentReport /> },
    { path: "/AgesReport", component: <AgesReport /> },
    { path: "/ShiftChangeRequest", component: <ShiftChangeRequest /> },
    { path: "/AdminShiftChange", component: <AdminShiftChange /> },

  
  ];

  return ( 
    <Router>
      <PathLogger />
      <ToastContainer />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Login" element={<Login />} />

        <Route
          path="/AccountInformation"
          element={
            <div className="no-select">
              <Topbar />
              <div className="layout-container">
                <SideBar className="sidebar" />
                <div className="content-area-main">
                  <AccountInformation />
                </div>
              </div>
            </div>
          }
        />

        {routes.map(({ path, component }) =>
          screenTypes.includes(path.replace('/', '')) ? (
            path.includes('Print') ? (
              <Route
                key={path}
                path={path}
                element={
                  <div className="px-4">{component}</div>
                }
              />
            ) : (
              <Route
                key={path}
                path={path}
                element={
                  <div className="no-select">
                    <Topbar />
                    <div className="layout-container">
                      <SideBar className="sidebar" />
                      <div className="content-area-main">{component}</div>
                    </div>
                  </div>
                }
              />
            )
          ) : (
            <Route
              key={path}
              path={path}
              element={
                <div className="no-select">
                  <SideBar className="sidebar" />
                  <Topbar />
                  <div className="layout-container">
                    <div className="content-area-main">
                      <NotFound />
                    </div>
                  </div>
                </div>
              }
            />
          )
        )}
      </Routes>
    </Router>
  );
}

const PathLogger = () => {
  const location = useLocation();

  useEffect(() => {
    const currentPath = location.pathname;

    sessionStorage.setItem('currentPath', currentPath);
  }, [location]);

  return null;
};

export default Main;