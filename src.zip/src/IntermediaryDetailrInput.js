import React, { useState, useEffect, useRef } from "react";
import "./input.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Select from 'react-select';
import IntermediaryHdrInputPopup from "./IntermediaryHeaderInput";
import { useLocation } from "react-router-dom";
import LoadingScreen from './Loading';
const config = require('./Apiconfig');

function IntermediaryDetailInput({ }) {
  const [open2, setOpen2] = React.useState(false);
  const [Code, setCode] = useState("");
  const [codeDetails, setCodeDetails] = useState("");
  const [intermediary_addr_1, setIntermediary_Addr_1] = useState("");
  const [intermediary_addr_2, setIntermediary_Addr_2] = useState("");
  const [intermediary_addr_3, setIntermediary_Addr_3] = useState("");
  const [intermediary_addr_4, setIntermediary_Addr_4] = useState("");
  const [intermediary_area_code, setIntermediary_Area_Code] = useState("");
  const [intermediary_stat_code, setIntermediary_Stat_Code] = useState("");
  const [intermediary_cnty_code, setIntermediary_Cnty_Code] = useState("");
  const [intermediary_imex_no, setIntermediary_Imex_No] = useState("");
  const [intermediary_office_no, setIntermediary_Office_No] = useState("");
  const [intermediary_resi_no, setIntermediary_Resi_No] = useState("");
  const [intermediary_mobile_no, setIntermediary_Mobile_No] = useState("");
  const [intermediary_fax_no, setIntermediary_Fax_No] = useState("");
  const [intermediary_email_id, setIntermediary_Email_Id] = useState("");
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [error, setError] = useState(false);
  const [intcodedrop, setintCodedrop] = useState([]);
  const [selectedHeader, setSelectedHeader] = useState('');
  const [drop, setDrop] = useState([]);
  const [condrop, setCondrop] = useState([]);
  const [statedrop, setStatedrop] = useState([]);
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedState, setselectedState] = useState('');
  const [selectedCountry, setselectedCountry] = useState('');
  const [isSelectedHeader, setIsSelectedHeader] = useState(false);
  const [isSelectCity, setIsSelectCity] = useState(false);
  const [isSelectState, setIsSelectState] = useState(false);
  const [isSelectCountry, setIsSelectCountry] = useState(false);

  const modified_by = sessionStorage.getItem("selectedUserCode");
  const [isUpdated, setIsUpdated] = useState(false);
  const location = useLocation();
  const locationState = location.state || {};
  const mode = locationState.mode || "create"; // ✅ default fallback
  const selectedRow = locationState.selectedRow || null;
  const codes = location.state?.Code;
  const codeDetail = location.state?.codeDetails;
  const company_code = sessionStorage.getItem('selectedCompanyCode');

  useEffect(() => {
    if (!location.state) {
      clearInputFields(); // ensure fresh create mode
    }
  }, []);

  useEffect(() => {
    if (mode === "update" && codes && codeDetail) {
      fetchIntermediaryData();
    }
  }, [mode, codes, codeDetail]);

  const fetchIntermediaryData = async () => {
    try {
      setLoading(true);

      const response = await fetch(`${config.apiBaseUrl}/getIntermediaryData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Code: codes,
          codeDetails: codeDetail,
          company_code
        }),
      });

      const data = await response.json();

      if (response.ok && data.length > 0) {
        const intermediary = data[0];

        setselectedState({
          label: intermediary.intermediary_stat_code,
          value: intermediary.intermediary_stat_code,
        });
        setSelectedCity({
          label: intermediary.intermediary_area_code,
          value: intermediary.intermediary_area_code,
        });
        setselectedCountry({
          label: intermediary.intermediary_cnty_code,
          value: intermediary.intermediary_cnty_code,
        });
        setSelectedHeader({
          label: intermediary.Code,
          value: intermediary.Code,
        });
        setCodeDetails(intermediary.codeDetails || "");
        setIntermediary_Addr_1(intermediary.intermediary_addr_1 || "");
        setIntermediary_Addr_2(intermediary.intermediary_addr_2 || "");
        setIntermediary_Addr_3(intermediary.intermediary_addr_3 || "");
        setIntermediary_Addr_4(intermediary.intermediary_addr_4 || "");
        setIntermediary_Imex_No(intermediary.intermediary_imex_no || "");
        setIntermediary_Office_No(intermediary.intermediary_office_no || "");
        setIntermediary_Resi_No(intermediary.intermediary_resi_no || "");
        setIntermediary_Mobile_No(intermediary.intermediary_mobile_no || "");
        setIntermediary_Fax_No(intermediary.intermediary_fax_no || "");
        setIntermediary_Email_Id(intermediary.intermediary_email_id || "");
        setIntermediary_Stat_Code(intermediary.intermediary_stat_code || "");
        setIntermediary_Area_Code(intermediary.intermediary_area_code || "");
        setIntermediary_Cnty_Code(intermediary.intermediary_cnty_code || "");
        setCode(intermediary.Code || "");
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to fetch intermediary details");
    } finally {
      setLoading(false);
    }
  };

  const clearInputFields = () => {
    setSelectedHeader("");
    setCodeDetails("");
    setIntermediary_Addr_1("");
    setIntermediary_Addr_2("");
    setIntermediary_Addr_3("");
    setIntermediary_Addr_4("");
    setIntermediary_Area_Code("");
    setIntermediary_Stat_Code("");
    setIntermediary_Cnty_Code("");
    setselectedState("");
    setSelectedCity("");
    setselectedCountry("");
    setIntermediary_Imex_No("");
    setIntermediary_Office_No("");
    setIntermediary_Resi_No("");
    setIntermediary_Mobile_No("");
    setIntermediary_Fax_No("");
    setIntermediary_Email_Id("");
  };

  // useEffect(() => {
  //   if (mode === "update" && selectedRow) {
  //     setselectedState({
  //       label: selectedRow.intermediary_stat_code,
  //       value: selectedRow.intermediary_stat_code,
  //     });
  //     setSelectedCity({
  //       label: selectedRow.intermediary_area_code,
  //       value: selectedRow.intermediary_area_code,
  //     });
  //     setselectedCountry({
  //       label: selectedRow.intermediary_cnty_code,
  //       value: selectedRow.intermediary_cnty_code,
  //     });
  //     setSelectedHeader({
  //       label: selectedRow.Code,
  //       value: selectedRow.Code,
  //     });
  //     setCodeDetails(selectedRow.codeDetails || "");
  //     setIntermediary_Addr_1(selectedRow.intermediary_addr_1 || "");
  //     setIntermediary_Addr_2(selectedRow.intermediary_addr_2 || "");
  //     setIntermediary_Addr_3(selectedRow.intermediary_addr_3 || "");
  //     setIntermediary_Addr_4(selectedRow.intermediary_addr_4 || "");
  //     setIntermediary_Imex_No(selectedRow.intermediary_imex_no || "");
  //     setIntermediary_Office_No(selectedRow.intermediary_office_no || "");
  //     setIntermediary_Resi_No(selectedRow.intermediary_resi_no || "");
  //     setIntermediary_Mobile_No(selectedRow.intermediary_mobile_no || "");
  //     setIntermediary_Fax_No(selectedRow.intermediary_fax_no || "");
  //     setIntermediary_Email_Id(selectedRow.intermediary_email_id || "");
  //     setIntermediary_Stat_Code(selectedRow.intermediary_stat_code || "");
  //     setIntermediary_Area_Code(selectedRow.intermediary_area_code || "");
  //     setIntermediary_Cnty_Code(selectedRow.intermediary_cnty_code || "");
  //     setCode(selectedRow.Code || "");

  //   } else if (mode === "create") {
  //     clearInputFields();
  //   }
  // }, [mode, selectedRow]);


  const Address3 = useRef(null);
  const Address4 = useRef(null);
  const codeD = useRef(null);
  const Address1 = useRef(null);
  const Address2 = useRef(null);
  const code = useRef(null);
  const City = useRef(null);
  const State = useRef(null);
  const Country = useRef(null);
  const IMEx = useRef(null);
  const Office = useRef(null);
  const Residential = useRef(null);
  const Mobile = useRef(null);
  const Fax = useRef(null);
  const Email = useRef(null);
  const [hasValueChanged, setHasValueChanged] = useState(false);
  const created_by = sessionStorage.getItem('selectedUserCode');

  const fetchHdrCode = () => {
    fetch(`${config.apiBaseUrl}/inthdrcode`)
      .then((data) => data.json())
      .then((val) => setintCodedrop(val));
  };

  useEffect(() => {
    fetchHdrCode();
  }, []);

  const filteredOptionHeader = Array.isArray(intcodedrop)
    ? intcodedrop.map((option) => ({
      value: option.Code,
      label: `${option.Code} - ${option.Details}`,
    }))
    : [];

  const handleChangeHeader = (selectedHeader) => {
    setSelectedHeader(selectedHeader);
    setCode(selectedHeader ? selectedHeader.value : '');
  };

  useEffect(() => {
    const company_code = sessionStorage.getItem('selectedCompanyCode');

    fetch(`${config.apiBaseUrl}/city`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ company_code })
    })
      .then((data) => data.json())
      .then((val) => setDrop(val))
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  useEffect(() => {
    const company_code = sessionStorage.getItem('selectedCompanyCode');

    fetch(`${config.apiBaseUrl}/country`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ company_code })
    })
      .then((data) => data.json())
      .then((val) => setCondrop(val))
      .catch((error) => console.error('Error fetching data:', error));
  }, []);


  useEffect(() => {
    const company_code = sessionStorage.getItem('selectedCompanyCode');

    fetch(`${config.apiBaseUrl}/state`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ company_code })
    })
      .then((data) => data.json())
      .then((val) => setStatedrop(val))
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  const filteredOptionCity = Array.isArray(drop)
    ? drop.map((option) => ({
      value: option.attributedetails_name,
      label: option.attributedetails_name,
    }))
    : [];

  const filteredOptionState = Array.isArray(statedrop)
    ? statedrop.map((option) => ({
      value: option.attributedetails_name,
      label: option.attributedetails_name,
    }))
    : [];

  const filteredOptionCountry = Array.isArray(condrop)
    ? condrop.map((option) => ({
      value: option.attributedetails_name,
      label: option.attributedetails_name,
    }))
    : [];

  const handleChangeCity = (selectedCity) => {
    setSelectedCity(selectedCity);
    setIntermediary_Area_Code(selectedCity ? selectedCity.value : '');
  };

  const handleChangeState = (selectedState) => {
    setselectedState(selectedState);
    setIntermediary_Stat_Code(selectedState ? selectedState.value : '');
  };

  const handleChangeCountry = (selectedCountry) => {
    setselectedCountry(selectedCountry);
    setIntermediary_Cnty_Code(selectedCountry ? selectedCountry.value : '');
  };

  const handleInsert = async () => {
    if (
      !Code ||
      !codeDetails ||
      !intermediary_addr_1 ||
      !intermediary_addr_2 ||
      !intermediary_area_code ||
      !intermediary_stat_code ||
      !intermediary_cnty_code ||
      !intermediary_imex_no ||
      !intermediary_office_no ||
      !intermediary_resi_no ||
      !intermediary_mobile_no ||
      !intermediary_email_id
    ) {
      setError(true);
      toast.warning("Missing Required Fields");
      return;
    }

    // Email validation
    if (!validateEmail(intermediary_email_id)) {
      setError(true);
      toast.warning("Please enter a valid email address");
      return;
    }
    setError(false);
    setLoading(true);

    try {
      const response = await fetch(`${config.apiBaseUrl}/addIntermediaryDetailData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          company_code: sessionStorage.getItem('selectedCompanyCode'),
          Code,
          codeDetails,
          intermediary_addr_1,
          intermediary_addr_2,
          intermediary_addr_3,
          intermediary_addr_4,
          intermediary_area_code,
          intermediary_stat_code,
          intermediary_cnty_code,
          intermediary_imex_no,
          intermediary_office_no,
          intermediary_resi_no,
          intermediary_mobile_no,
          intermediary_fax_no,
          intermediary_email_id,
          created_by: sessionStorage.getItem('selectedUserCode')
        }),
      });

      if (response.ok) {
        toast.success("Data inserted successfully", {
          onClose: () => {
            clearInputFields();
            setError(false)
          }
        });
      } else {
        const errorResponse = await response.json();
        console.error(errorResponse.message);
        toast.warning(errorResponse.message);
      }
    } catch (error) {
      console.error("Error inserting data:", error);
      toast.error('Error inserting data: ' + error.message, {

      });
    } finally {
      setLoading(false);
    }
  };

  const handleNavigateToForm = () => {
    navigate("/AddIntermedHeader", { selectedRows }); // Pass selectedRows as props to the Input component
  };

  function validateEmail(email) {
    const emailRegex = /^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/;
    return emailRegex.test(email);
  }

  const handleNavigate = () => {
    navigate("/Intermediary", {
      state: {
        refreshGrid: true,
        // preservedRowData: location.state?.preservedRowData,
        preservedInputs: location.state?.preservedInputs
      }
    });
  };

  const handleKeyDown = async (e, nextFieldRef, value, hasValueChanged, setHasValueChanged) => {
    if (e.key === 'Enter') {
      // Check if the value has changed and handle the search logic
      if (hasValueChanged) {
        await handleKeyDownStatus(e); // Trigger the search function
        setHasValueChanged(false); // Reset the flag after the search
      }

      // Move to the next field if the current field has a valid value
      if (value) {
        nextFieldRef.current.focus();
      } else {
        e.preventDefault(); // Prevent moving to the next field if the value is empty
      }
    }
  };


  const handleKeyDownStatus = async (e) => {
    if (e.key === 'Enter' && hasValueChanged) { // Only trigger search if the value has changed
      // Trigger the search function
      setHasValueChanged(false); // Reset the flag after search
    }
  };

  const handleClickOpen = (params) => {
    setOpen2(true);
    console.log("Opening popup...");
  };
  const handleClose = () => {
    setOpen2(false);
    fetchHdrCode();
  };


  const handleUpdate = async () => {
    if (
      !selectedHeader ||
      !codeDetails ||
      !intermediary_addr_1 ||
      !intermediary_addr_2 ||
      !selectedCity ||
      !selectedCountry ||
      !selectedState ||
      !intermediary_imex_no ||
      !intermediary_office_no ||
      !intermediary_resi_no ||
      !intermediary_mobile_no ||
      !intermediary_email_id
    ) {
      setError(true);
      toast.warning("Error: Missing required fields");
      return;
    }

    if (!validateEmail(intermediary_email_id)) {
      setError(true);
      toast.warning("Please enter a valid email address");
      return;
    }
    setError(false);
    setLoading(true);

    try {
      const response = await fetch(`${config.apiBaseUrl}/IntermediaryUpdate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          company_code: sessionStorage.getItem('selectedCompanyCode'),
          Code: selectedHeader.value,
          codeDetails,
          intermediary_addr_1,
          intermediary_addr_2,
          intermediary_addr_3,
          intermediary_addr_4,
          intermediary_area_code: selectedCity.value,
          intermediary_stat_code: selectedState.value,
          intermediary_cnty_code: selectedCountry.value,
          intermediary_imex_no,
          intermediary_office_no,
          intermediary_resi_no,
          intermediary_mobile_no,
          intermediary_fax_no,
          intermediary_email_id,
          created_by,
          modified_by,
        }),
      });
      if (response.ok) {
        toast.success("Data updated successfully", {
          onClose: () => {
            // clearInputFields();
            setError(false)
          }
        });
      } else {
        const errorResponse = await response.json();
        console.error(errorResponse.message);
        toast.warning(errorResponse.message);
      }
    } catch (error) {
      console.error("Error Update data:", error);
      toast.error('Error inserting data: ' + error.message);
    }
    finally {
      setLoading(false);
    }
  };

  return (
    <div class="container-fluid Topnav-screen ">
      <div className="">
        <div class=""  >
          {loading && <LoadingScreen />}
          <ToastContainer position="top-right" className="toast-design" theme="colored" />
          <div className="shadow-lg p-1 bg-light rounded main-header-box">
            <div className="header-flex">

              <h1 className="page-title"> {mode === "update" ? 'Update Intermediary Details ' : 'Add Intermediary Details'}</h1>
              <div className="action-wrapper">
                <div className="action-icon delete" onClick={handleNavigate}>
                  <span className="tooltip">Close</span>
                  <i className="fa-solid fa-xmark"></i>
                </div>
              </div>
            </div>
          </div>

          <div className="shadow-lg p-3 bg-light rounded mt-2 container-form-box">
            <div className="row g-3">

              <div className="col-md-2">
                <div
                  className={`inputGroup selectGroup 
                  ${selectedHeader ? "has-value" : ""} 
                  ${isSelectedHeader ? "is-focused" : ""}`}
                  title="Please Select the Code"
                >
                  <Select
                    id="ihcode"
                    value={selectedHeader}
                    onChange={handleChangeHeader}
                    options={filteredOptionHeader}
                    placeholder=" "
                    onFocus={() => setIsSelectedHeader(true)}
                    onBlur={() => setIsSelectedHeader(false)}
                    classNamePrefix="react-select"
                    isClearable
                    ref={code}
                    readOnly={mode === "update"}
                    isDisabled={mode === "update"}
                    onKeyDown={(e) => handleKeyDown(e, codeD, code)}
                  />
                  {mode !== "update" && (
                    <span
                      type="button"
                      className="select-add-btn"
                      title="Add Header"
                      onClick={handleClickOpen}
                    >
                      <i className="fa-solid fa-plus"></i>
                    </span>
                  )}
                  <label For="city" className={`floating-label ${error && !Code ? 'text-danger' : ''}`}>Code<span className="text-danger">*</span></label>


                </div>
              </div>



              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idcode"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Details Code"
                    value={codeDetails}
                    maxLength={250}
                    onChange={(e) => setCodeDetails(e.target.value)}
                    ref={codeD}
                    readOnly={mode === "update"}
                    onKeyDown={(e) => handleKeyDown(e, Address1, codeD)}
                  />
                  <label for="rid" className={`exp-form-labels ${error && !codeDetails ? 'text-danger' : ''}`}>Details Code<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idaddr1"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Address 1"
                    value={intermediary_addr_1}
                    maxLength={250}
                    onChange={(e) => setIntermediary_Addr_1(e.target.value)}
                    ref={Address1}
                    onKeyDown={(e) => handleKeyDown(e, Address2, Address1)}
                  />
                  <label for="rid" className={`exp-form-labels ${error && !intermediary_addr_1 ? 'text-danger' : ''}`}>Address 1<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idaddr2"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Address 2"
                    value={intermediary_addr_2}
                    maxLength={250}
                    onChange={(e) => setIntermediary_Addr_2(e.target.value)}
                    ref={Address2}
                    onKeyDown={(e) => handleKeyDown(e, Address3, Address2)}
                  />
                  <label for="rid" className={`exp-form-labels ${error && !intermediary_addr_2 ? 'text-danger' : ''}`}>Address 2<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idaddr3"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Address 3"
                    value={intermediary_addr_3}
                    maxLength={250}
                    onChange={(e) => setIntermediary_Addr_3(e.target.value)}
                    ref={Address3}
                    onKeyDown={(e) => handleKeyDown(e, Address4, Address3)}
                  />
                  <label for="rid" className={`exp-form-labels ${error && !intermediary_addr_3 ? 'text-danger' : ''}`}>Address 3<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idaddr4"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Address 4"
                    value={intermediary_addr_4}
                    maxLength={250}
                    onChange={(e) => setIntermediary_Addr_4(e.target.value)}
                    ref={Address4}
                    onKeyDown={(e) => handleKeyDown(e, City, Address4)}
                  />
                  <label for="rid" className={`exp-form-labels ${error && !intermediary_addr_4 ? 'text-danger' : ''}`}>Address 4<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div
                  className={`inputGroup selectGroup 
                  ${selectedCity ? "has-value" : ""} 
                  ${isSelectCity ? "is-focused" : ""}`}
                  title="Please Select the City"
                >
                  <Select
                    id="city"
                    value={selectedCity}
                    onChange={handleChangeCity}
                    options={filteredOptionCity}
                    placeholder=" "
                    onFocus={() => setIsSelectCity(true)}
                    onBlur={() => setIsSelectCity(false)}
                    classNamePrefix="react-select"
                    isClearable
                    ref={City}
                    onKeyDown={(e) => handleKeyDown(e, State, City)}
                  />
                  <label For="city" className={`floating-label ${error && !intermediary_area_code ? 'text-danger' : ''}`}>City<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div
                  className={`inputGroup selectGroup 
                  ${selectedState ? "has-value" : ""} 
                  ${isSelectState ? "is-focused" : ""}`}
                  title="Please Select the State"
                >
                  <Select
                    id="state"
                    value={selectedState}
                    onChange={handleChangeState}
                    options={filteredOptionState}
                    isClearable
                    classNamePrefix="react-select"
                    placeholder=" "
                    onFocus={() => setIsSelectState(true)}
                    onBlur={() => setIsSelectState(false)}
                    ref={State}
                    onKeyDown={(e) => handleKeyDown(e, Country, State)}
                  />
                  <label for="state" className={`floating-label ${error && !intermediary_stat_code ? 'text-danger' : ''}`}>State<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div
                  className={`inputGroup selectGroup 
                  ${selectedCountry ? "has-value" : ""} 
                  ${isSelectCountry ? "is-focused" : ""}`}
                  title="Please Select the Country"
                >
                  <Select
                    id="country"
                    value={selectedCountry}
                    onChange={handleChangeCountry}
                    options={filteredOptionCountry}
                    isClearable
                    classNamePrefix="react-select"
                    placeholder=""
                    onFocus={() => setIsSelectCountry(true)}
                    onBlur={() => setIsSelectCountry(false)}
                    ref={Country}
                    onKeyDown={(e) => handleKeyDown(e, IMEx, Country)}
                  />
                  <label for="country" className={`floating-label ${error && !intermediary_cnty_code ? 'text-danger' : ''}`}>Country<span className="text-danger">*</span></label>
                </div>
              </div>



              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idimexno"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the IMEX No"
                    value={intermediary_imex_no}
                    maxLength={10}
                    onChange={(e) => setIntermediary_Imex_No(e.target.value)}
                    ref={IMEx}
                    onKeyDown={(e) => handleKeyDown(e, Office, IMEx)}
                  />
                  <label for="IMEX" className={`exp-form-labels ${error && !intermediary_imex_no ? 'text-danger' : ''}`}>IMEX No<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idofficeno"
                    class="exp-input-field form-control"
                    type="Number"
                    placeholder=""
                    required title="Please Enter the Office No"
                    value={intermediary_office_no}
                    maxLength={20}
                    ref={Office}
                    onKeyDown={(e) => handleKeyDown(e, Residential, Office)}
                    onChange={(e) => setIntermediary_Office_No(e.target.value.replace(/\D/g, '').slice(0, 50))}
                  />
                  <label for="Office No " className={`exp-form-labels ${error && !intermediary_office_no ? 'text-danger' : ''}`}>Office No<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idresno"
                    class="exp-input-field form-control"
                    type="Number"
                    placeholder=""
                    required title="Please Enter the Residential No"
                    value={intermediary_resi_no}
                    maxLength={20}
                    ref={Residential}
                    onKeyDown={(e) => handleKeyDown(e, Mobile, Residential)}
                    onChange={(e) => setIntermediary_Resi_No(e.target.value.replace(/\D/g, '').slice(0, 50))}
                  />
                  <label for="idresno" className={`exp-form-labels ${error && !intermediary_resi_no ? 'text-danger' : ''}`}>Residential No<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idmobno"
                    class="exp-input-field form-control"
                    type="Number"
                    placeholder=""
                    required title="Please Enter the Mobile No"
                    value={intermediary_mobile_no}
                    maxLength={50}
                    ref={Mobile}
                    onKeyDown={(e) => handleKeyDown(e, Fax, Mobile)}
                    onChange={(e) => setIntermediary_Mobile_No(e.target.value.replace(/\D/g, '').slice(0, 50))}
                  />
                  <label for="idmobno" className={`exp-form-labels ${error && !intermediary_mobile_no ? 'text-danger' : ''}`}>Mobile No<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idfaxno"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Fax No"
                    value={intermediary_fax_no}
                    maxLength={20}
                    ref={Fax}
                    onKeyDown={(e) => handleKeyDown(e, Email, Fax)}
                    onChange={(e) => setIntermediary_Fax_No(e.target.value)}
                  />
                  <label for="idfaxno" className={`exp-form-labels ${error && !intermediary_fax_no ? 'text-danger' : ''}`}>Fax No <span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="idemailid"
                    class="exp-input-field form-control"
                    type="Email"
                    placeholder=""
                    required title="Please Enter the Email ID"
                    value={intermediary_email_id}
                    maxLength={250}
                    ref={Email}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        if (mode === "create") {
                          handleInsert();
                        } else {
                          handleUpdate();
                        }
                      }
                    }}
                    onChange={(e) => setIntermediary_Email_Id(e.target.value)}
                  />
                  <label for="idfaxno" className={`exp-form-labels ${error && !intermediary_email_id ? 'text-danger' : ''}`}> Email ID<span className="text-danger">*</span></label>
                </div>
              </div>

              <div class="col-12">
                <div className="search-btn-wrapper">
                  {mode === "create" ? (
                    <div className="icon-btn save" onClick={handleInsert}>
                      <span className="tooltip">Save</span>
                      <i class="fa-solid fa-floppy-disk"></i>
                    </div>
                  ) : (
                    <div className="icon-btn update" onClick={handleUpdate}>
                      <span className="tooltip">Update</span>
                      <i class="fa-solid fa-pen-to-square"></i>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div>
              <IntermediaryHdrInputPopup open={open2} handleClose={handleClose} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default IntermediaryDetailInput;