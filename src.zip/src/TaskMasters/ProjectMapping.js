import { useState, useEffect } from "react";
import "../input.css";
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer, toast } from 'react-toastify';
import Select from 'react-select';
import { AgGridReact } from "ag-grid-react";
import LoadingScreen from '../Loading';
import { showConfirmationToast } from '../ToastConfirmation';
const config = require('../Apiconfig');

function Input({ }) {
  const [rowData, setRowData] = useState([]);
  const [error, setError] = useState("");
  const [userDrop, setUserDrop] = useState([]);
  const [userDropAg, setUserDropAg] = useState([]);
  const [userDropSc, setUserDropSc] = useState([]);
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedUserSc, setSelectedUserSc] = useState('');
  const [user, setUser] = useState("");
  const [userSc, setUserSc] = useState("");
  const [projectDrop, setProjectDrop] = useState([]);
  const [projectDropAg, setProjectDropAg] = useState([]);
  const [projectDropSc, setProjectDropSc] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [selectedProjectSc, setSelectedProjectSc] = useState('');
  const [project, setProject] = useState("");
  const [projectSc, setProjectSc] = useState("");
  const [projectId, setProjectId] = useState("");
  const [Projectname, setProjectname] = useState("");
  const [userId, setUserId] = useState("");
  const [userIdSc, setUserIdSc] = useState("");
  const [user_name, setuser_name] = useState("");
  const [user_nameSc, setuser_nameSc] = useState("");
  const [userCodeDrop, setUserCodeDrop] = useState([]);
  const [projectCodeDrop, setProjectCodeDrop] = useState([]);
  const [status, setstatus] = useState("");
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [statusdrop, setStatusdrop] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isSelectProject, setIsSelectProject] = useState(false);
  const [isSelectProjectSc, setIsSelectProjectSc] = useState(false);
  const [isSelectUser, setIsSelectUser] = useState(false);
  const [isSelectUserSc, setIsSelectUserSc] = useState(false);
  const [isSelectStatus, setIsSelectStatus] = useState(false);

  const permissions = JSON.parse(sessionStorage.getItem("permissions")) || {};
  const projectMappingPermission = permissions
    .filter((permission) => permission.screen_type === "ProjectMapping")
    .map((permission) => permission.permission_type.toLowerCase());

  // //UserEffect for React Select
  // useEffect(() => {
  //   fetch(`${config.apiBaseUrl}/getProjectDrop`)
  //     .then((data) => data.json())
  //     .then((val) => setProjectDrop(val));
  // }, []);


  const company_code = sessionStorage.getItem("selectedCompanyCode")

  useEffect(() => {
    if (!company_code) return; // Only run if company_code exists

    fetch(`${config.apiBaseUrl}/getProjectDrop`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ company_code })
    })
      .then((response) => response.json())
      .then((data) => {
        setProjectDrop(data);
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  useEffect(() => {
    fetch(`${config.apiBaseUrl}/getProjectDrop`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        company_code: sessionStorage.getItem("selectedCompanyCode"),
      }),
    })
      .then((data) => data.json())
      .then((val) => {
        const loan = val.map((option) => ({
          value: option.ProjectID,
          label: `${option.ProjectID}`,
        }));

        setProjectDropAg(loan);
      })
      .catch((error) => console.error("Error fetching loan request:", error));
  }, []);

  useEffect(() => {
    if (!company_code) return; // Only run if company_code exists

    fetch(`${config.apiBaseUrl}/getProjectDrop`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ company_code })
    })
      .then((response) => response.json())
      .then((data) => {
        setProjectDropSc(data);
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  useEffect(() => {
    fetch(`${config.apiBaseUrl}/Usercode`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        company_code: sessionStorage.getItem("selectedCompanyCode"),
      }),
    })
      .then((data) => data.json())
      .then((val) => {
        const user = val.map((option) => ({
          value: option.user_code,
          label: `${option.user_code}`,
        }));

        setUserDropAg(user);
      })
      .catch((error) => console.error("Error fetching user:", error));
  }, []);


  useEffect(() => {
    fetch(`${config.apiBaseUrl}/Usercode`)
      .then((data) => data.json())
      .then((val) => setUserDrop(val));
  }, []);

  useEffect(() => {
    fetch(`${config.apiBaseUrl}/Usercode`)
      .then((data) => data.json())
      .then((val) => setUserDropSc(val));
  }, []);

  const filteredOptionProject = Array.isArray(projectDrop)
    ? projectDrop.map((option) => ({
      value: option.ProjectID,
      label: `${option.ProjectID} - ${option.ProjectName}`
    }))
    : [];

  const filteredOptionProjectSc = Array.isArray(projectDropSc)
    ? projectDropSc.map((option) => ({
      value: option.ProjectID,
      label: `${option.ProjectID} - ${option.ProjectName}`
    }))
    : [];

  // const filteredOptionUser = Array.isArray(userDrop)
  //   ? userDrop.map((option) => ({
  //     value: option.user_code,
  //     label: `${option.user_code} - ${option.user_name}`,
  //   }))
  //   : [];
  const filteredOptionUser = Array.isArray(userDrop)
    ? userDrop.map((option) => ({
      value: option.user_code,
      label: `${option.user_code} - ${option.user_name}`,
    }))
    : [];

  const filteredOptionUserSc = Array.isArray(userDropSc)
    ? userDropSc.map((option) => ({
      value: option.user_code,
      label: `${option.user_code} - ${option.user_name}`,
    }))
    : [];

  //    useEffect(() => {
  //   const fetchUserCodes = async () => {
  //     try {
  //       const response = await fetch(`${config.apiBaseUrl}/getEmployeeId`, {
  //         method: 'POST',
  //         headers: {
  //           'Content-Type': 'application/json',
  //         },
  //         body: JSON.stringify({ company_code: sessionStorage.getItem('selectedCompanyCode') })
  //       });
  //       const data = await response.json();

  //       if (response.ok && Array.isArray(data)) {
  //         setUserDrop(data);

  //         // Optionally set the first user as selected if needed
  //         if (data.length > 0) {
  //           const defaultOption = {
  //             value: data[0].EmployeeId,
  //             label: data[0].First_Name
  //           };
  //           setSelectedUser(defaultOption);
  //           setUser(defaultOption.value);
  //         }
  //       } else {
  //         console.warn("No data found for user codes");
  //         setUserDrop([]);
  //       }
  //     } catch (error) {
  //       console.error("Error fetching user codes:", error);
  //     }
  //   };

  //   fetchUserCodes();
  // }, []);
  //  useEffect(() => {
  //         fetch(`${config.apiBaseUrl}/getTaskUserID`, {
  //           method: 'POST',
  //           headers: {
  //             'Content-Type': 'application/json',
  //           },
  //           body: JSON.stringify({
  //             // user_code: sessionStorage.getItem("selectedUserCode"),
  //             company_code: sessionStorage.getItem("selectedCompanyCode"),
  //           }),
  //         })
  //           .then((response) => response.json())
  //           .then(setUserDrop)
  //           .catch((error) => console.error("Error fetching user codes:", error));
  //       }, []);


  const filteredOptionStatus = statusdrop.map((option) => ({
    value: option.attributedetails_name,
    label: option.attributedetails_name,
  }));

  useEffect(() => {
    const company_code = sessionStorage.getItem('selectedCompanyCode');

    fetch(`${config.apiBaseUrl}/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ company_code }),
    })
      .then((response) => response.json())
      .then((val) => {
        setStatusdrop(val);

        if (val.length > 0) {
          const firstOption = {
            value: val[0].attributedetails_name,
            label: val[0].attributedetails_name,
          };
          setSelectedStatus(firstOption);
          setstatus(firstOption.value);
        }
      })
      .catch((error) => {
        console.error('Error fetching status data:', error);
      });
  }, []);

  const handleChangeStatus = (selectedStatus) => {
    setSelectedStatus(selectedStatus);
    setstatus(selectedStatus ? selectedStatus.value : '');
  };


  const handleChangeProject = (selectedProject) => {
    setSelectedProject(selectedProject);
    setProject(selectedProject ? selectedProject.value : '');
  };
  const handleChangeProjectSc = (selectedProjectSc) => {
    setSelectedProjectSc(selectedProjectSc);
    setProjectSc(selectedProjectSc ? selectedProjectSc.value : '');
  };

  const handleChangeUser = (selectedUser) => {
    setSelectedUser(selectedUser);
    setUser(selectedUser ? selectedUser.value : '');
  };

  const handleChangeUserSc = (selectedUserSc) => {
    setSelectedUserSc(selectedUserSc);
    setUserSc(selectedUserSc ? selectedUserSc.value : '');
  };

  // //useEffect for Ag grid Filter Option
  // useEffect(() => {
  //   fetch(`${config.apiBaseUrl}/getProjectDrop`)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       const ProjectOption = data.map((option) => option.ProjectID);
  //       setProjectCodeDrop(ProjectOption);
  //     })
  //     .catch((error) => console.error("Error fetching data:", error));
  // }, []);


  // useEffect(() => {
  //   fetch(`${config.apiBaseUrl}/usercode`)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       const UserOption = data.map((option) => option.user_code);
  //       setUserCodeDrop(UserOption);
  //     })
  //     .catch((error) => console.error("Error fetching data:", error));
  // }, []);

  const columnDefs = [
    {
      headerName: "Actions",
      field: "actions",
      // minWidth: 100,
      // maxWidth: 100,
      cellRenderer: (params) => {
        const cellWidth = params.column.getActualWidth();
        const isWideEnough = cellWidth > 20;
        const showIcons = isWideEnough;

        return (
          <div className="position-relative d-flex align-items-center" style={{ minHeight: '100%', justifyContent: 'center' }}>
            {showIcons && (
              <>
                <span
                  className="icon mx-2"
                  onClick={() => handleUpdate(params.data, params.node.data)}
                  style={{ cursor: 'pointer' }}
                >
                  <i className="fa-regular fa-floppy-disk"></i>
                </span>

                <span
                  className="icon mx-2"
                  onClick={() => handleDelete(params.data)}
                  style={{ cursor: 'pointer' }}
                >
                  <i className="fa-solid fa-trash"></i>
                </span>
              </>
            )}
          </div>
        );
      },
    },
    {
      headerName: "Project ID",
      field: "ProjectID",
      editable: true,
      cellEditor: "agSelectCellEditor",
      cellEditorParams: {
        values: projectDropAg.map((d) => d.value),
      },
      valueFormatter: (params) => {
        const loan = projectDropAg.find((d) => d.value === params.value);
        return loan ? loan.label : params.value;
      },
    },
    {
      headerName: "Project Name",
      field: "ProjectName",
      editable: true,
    },
    {
      headerName: "User ID",
      field: "userID",
      editable: true,
      cellEditor: "agSelectCellEditor",
      cellEditorParams: {
        values: userDropAg.map((d) => d.value),
      },
      valueFormatter: (params) => {
        const user = userDropAg.find((d) => d.value === params.value);
        return user ? user.label : params.value;
      },
    },
    {
      headerName: "User Name",
      field: "user_name",
      editable: true,
    },
    {
      headerName: "Keyfield",
      field: "keyfield",
      hide: true
    },
  ]
  const gridOptions = {
    pagination: true,
    paginationPageSize: 10,
  };

  const handleSave = async () => {
    if (!user || !project) {
      setError(" ");
      toast.warning("Error: Missing required fields");
      return;
    }
    setLoading(true);
    try {
      const Header = {
        ProjectID: project,
        userID: user,
        created_by: sessionStorage.getItem('selectedUserCode'),
        company_code: sessionStorage.getItem('selectedCompanyCode')
      };

      const response = await fetch(`${config.apiBaseUrl}/addProjectMapping`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(Header),
      });
      if (response.status === 200) {
        console.log("Data inserted successfully");
        setTimeout(() => {
          toast.success("Data inserted successfully!", {
            onClose: () => window.location.reload(),
          });
        }, 1000);
      } else {
        const errorResponse = await response.json();
        toast.warning(errorResponse.message || "Failed to insert data");
        console.error(errorResponse.details || errorResponse.message);
      }
    } catch (error) {
      console.error("Error inserting data:", error);
      toast.error('Error inserting data: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    setLoading(true);
    try {
      const body = {
        ProjectID: projectSc,
        ProjectName: Projectname,
        user_name: user_name,
        userID: userSc,
        company_code: sessionStorage.getItem('selectedCompanyCode')

      };

      const response = await fetch(`${config.apiBaseUrl}/getProjectMapping`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      if (response.ok) {
        const fetchedData = await response.json();
        const newRows = fetchedData.map((matchedItem) => ({
          ProjectID: matchedItem.ProjectID,
          ProjectName: matchedItem.ProjectName,
          user_name: matchedItem.user_name,
          userID: matchedItem.userID,
          keyfield: matchedItem.keyfield,
        }));
        setRowData(newRows);
      } else if (response.status === 404) {
        console.log("Data Not found");
        toast.warning("Data Not found");
        setRowData([]);
      } else {
        const errorResponse = await response.json();
        toast.warning(errorResponse.message || "Failed to insert sales data");
        console.error(errorResponse.details || errorResponse.message);
        setRowData([]);
      }
    } catch (error) {
      console.error("Error fetching search data:", error);
    } finally {
      setLoading(false);
    }
  };

  const reloadGridData = () => {
    window.location.reload();
  };

  const searchClearInputFields = () => {
    setProjectSc("");
    setUserSc("");
    setProjectname("");
    setuser_name("");
    setSelectedProjectSc("");
    setSelectedUserSc("");
  };

  const reloadData = () => {
    setRowData([]);
    searchClearInputFields();

  };


  const handleUpdate = async (rowData) => {
    showConfirmationToast(
      "Are you sure you want to Update the data in the selected rows?",
      async () => {
        setLoading(true);
        try {
          const modified_by = sessionStorage.getItem('selectedUserCode');

          // const dataToSend = { editedData: Array.isArray(rowData) ? rowData : [rowData] };
          
          const dataToSend = {
            editedData: Array.isArray(rowData)
              ? rowData.map((row) => ({
                ...row,
                company_code,
                modified_by,
              }))
              : [
                {
                  ...rowData,
                  company_code,
                  modified_by,
                },
              ],
          };

          const response = await fetch(`${config.apiBaseUrl}/updateProjectMapping`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(dataToSend)
          });

          if (response.ok) {
            toast.success("Data updated successfully", {
              onClose: () => handleSearch(), 
            });
          } else {
            const errorResponse = await response.json();
            toast.warning(errorResponse.message || "Failed to insert sales data");
          }
        } catch (error) {
          console.error("Error deleting rows:", error);
          toast.error('Error Deleting Data: ' + error.message);
        } finally {
          setLoading(false);
        }
      },
      () => {
        toast.info("Data updated cancelled.");
      }
    );
  };

  const handleDelete = async (rowData) => {
    showConfirmationToast(
      "Are you sure you want to Delete the data in the selected rows?",
      async () => {
        setLoading(true);
        try {
          const modified_by = sessionStorage.getItem("selectedUserCode");
          // const dataToSend = { editedData: Array.isArray(rowData) ? rowData : [rowData] };
          
          const dataToSend = {
            editedData: Array.isArray(rowData)
              ? rowData.map((row) => ({
                ...row,
                company_code,
                modified_by,
              }))
              : [
                {
                  ...rowData,
                  company_code,
                  modified_by,
                },
              ],
          };

          const response = await fetch(`${config.apiBaseUrl}/deleteProjectMapping`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify(dataToSend)
          });

          if (response.ok) {
            toast.success("Data deleted successfully", {
              onClose: () => handleSearch(),
            });
          } else {
            const errorResponse = await response.json();
            toast.warning(errorResponse.message || "Failed to insert sales data");
          }
        } catch (error) {
          console.error("Error deleting rows:", error);
          toast.error('Error Deleting Data: ' + error.message);
        } finally {
          setLoading(false);
        }
      },
      () => {
        toast.info("Data deleted cancelled.");
      }
    );
  };

  return (
    <div class="container-fluid Topnav-screen">
      {loading && <LoadingScreen />}
      <ToastContainer position="top-right" className="toast-design" theme="colored" />
      <div className="shadow-lg p-1 bg-light rounded main-header-box">
        <div className="header-flex">
          <h1 className="page-title">Project Mapping</h1>

          <div className="action-wrapper desktop-actions">
            {['add', 'all permission'].some(p => projectMappingPermission.includes(p)) && (
              <div className="action-icon add" onClick={handleSave}>
                <span className="tooltip">Save</span>
                <i class="fa-solid fa-floppy-disk"></i>
              </div>
            )}
            <div className="action-icon print" onClick={reloadGridData}>
              <span className="tooltip">Reload</span>
              <i className="fa-solid fa-arrow-rotate-right"></i>
            </div>
          </div>

          {/* Mobile Dropdown */}
          <div className="dropdown mobile-actions">
            <button
              className="btn btn-primary dropdown-toggle p-0"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              <i className="fa-solid fa-ellipsis-vertical"></i>
            </button>

            <ul className="dropdown-menu dropdown-menu-end text-center">
              {['add', 'all permission'].some(p => projectMappingPermission.includes(p)) && (
                <li>
                  <button className="dropdown-item" onClick={handleSave}>
                    <i className="fa-solid fa-floppy-disk add fs-4"></i>
                  </button>
                </li>
              )}
              <li>
                <button className="dropdown-item" onClick={reloadGridData}>
                  <i className="fa-solid fa-arrow-rotate-right text-dark fs-4"></i>
                </button>
              </li>
            </ul>
          </div>

        </div>
      </div>

      <div className="shadow-lg p-3 bg-light rounded mt-2 container-form-box">
        <div className="row g-3">

          <div className="col-md-2">
            <div
              className={`inputGroup selectGroup 
              ${selectedProject ? "has-value" : ""} 
              ${isSelectProject ? "is-focused" : ""}`}
              title="Please select the Project"
            >
              <Select
                id="gradeid"
                placeholder=" "
                onFocus={() => setIsSelectProject(true)}
                onBlur={() => setIsSelectProject(false)}
                classNamePrefix="react-select"
                isClearable
                onChange={handleChangeProject}
                value={selectedProject}
                options={filteredOptionProject}
              />
              <label for="sname" className={`floating-label ${error && !project ? 'text-danger' : ''}`}>Project<span className="text-danger">*</span></label>
            </div>
          </div>

          <div className="col-md-2">
            <div
              className={`inputGroup selectGroup 
              ${selectedUser ? "has-value" : ""} 
              ${isSelectUser ? "is-focused" : ""}`}
              title="Please select the User"
            >
              <Select
                id="gradeid"
                placeholder=" "
                onFocus={() => setIsSelectUser(true)}
                onBlur={() => setIsSelectUser(false)}
                classNamePrefix="react-select"
                isClearable
                onChange={handleChangeUser}
                value={selectedUser}
                options={filteredOptionUser}
              />
              <label for="sname" className={`floating-label ${error && !user ? 'text-danger' : ''}`}>User<span className="text-danger">*</span></label>
            </div>
          </div>

          {/*<div className="col-md-2">
            <div
              className={`inputGroup selectGroup 
              ${selectedStatus ? "has-value" : ""} 
              ${isSelectStatus ? "is-focused" : ""}`}
            >
              <Select
                type='Text'
                placeholder=" "
                onFocus={() => setIsSelectStatus(true)}
                onBlur={() => setIsSelectStatus(false)}
                classNamePrefix="react-select"
                isClearable
                onChange={handleChangeStatus}
                value={selectedStatus}
                options={filteredOptionStatus}
              // onKeyDown={(e) => e.key === "Enter" && handleChange()}
              />
              <label className="floating-label">Status</label>
            </div>
          </div> */}
        </div>
      </div>

      <div className="shadow-lg p-3 bg-light rounded mt-2 container-form-box">
        <h5>Search Criteria :</h5>
        <div className="row g-3">

          {/* <div className="col-md-2">
            <div className="inputGroup">
              <input
                id="fdate"
                class="exp-input-field form-control"
                type="text"
                placeholder=" "
                autoComplete="off"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
              <label className="exp-form-labels">Project ID</label>
            </div>
          </div> */}

          <div className="col-md-2">
            <div
              className={`inputGroup selectGroup 
              ${selectedProjectSc ? "has-value" : ""} 
              ${isSelectProjectSc ? "is-focused" : ""}`}
              title="Please select the Project ID"
            >
              <Select
                id="gradeid"
                placeholder=" "
                onFocus={() => setIsSelectProjectSc(true)}
                onBlur={() => setIsSelectProjectSc(false)}
                classNamePrefix="react-select"
                isClearable
                onChange={handleChangeProjectSc}
                value={selectedProjectSc}
                options={filteredOptionProjectSc}
              />
              <label for="sname" className={`floating-label `}>Project ID</label>
            </div>
          </div>

          <div className="col-md-2">
            <div className="inputGroup">
              <input
                id="ProjectName"
                type="text"
                placeholder=" "
                autoComplete="off"
                className="exp-input-field form-control"
                title="Please Enter the Project Name"
                value={Projectname}
                maxLength={255}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                onChange={(e) => setProjectname(e.target.value)}
              />
              <label for="cname" className="exp-form-labels">Project Name</label>
            </div>
          </div>

          {/* <div className="col-md-2">
            <div className="inputGroup">
              <input
                id="fdate"
                class="exp-input-field form-control"
                type="text"
                placeholder=" "
                autoComplete="off"
                value={userId}
                onChange={handleChangeUser}
                options={filteredOptionUser}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
              <label className="exp-form-labels">User ID</label>
            </div>
          </div> */}

          <div className="col-md-2">
            <div
              className={`inputGroup selectGroup 
              ${selectedUserSc ? "has-value" : ""} 
              ${isSelectUserSc ? "is-focused" : ""}`}
              title="Please select the User ID"
            >
              <Select
                id="gradeid"
                placeholder=" "
                onFocus={() => setIsSelectUserSc(true)}
                onBlur={() => setIsSelectUserSc(false)}
                classNamePrefix="react-select"
                isClearable
                onChange={handleChangeUserSc}
                value={selectedUserSc}
                options={filteredOptionUserSc}
              />
              <label for="sname" className={`floating-label `}>User ID</label>
            </div>
          </div>

          <div className="col-md-2">
            <div className="inputGroup">
              <input
                id="username"
                className="exp-input-field form-control"
                title="Please Enter the User Name"
                type="text"
                placeholder=" "
                autoComplete="off"
                value={user_name}
                onChange={(e) => setuser_name(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                maxLength={250}
              />
              <label for="username" className="exp-form-labels">User Name</label>
            </div>
          </div>

          <div className="col-12">
            <div className="search-btn-wrapper">
              <div className="icon-btn search" onClick={handleSearch}>
                <span className="tooltip">Search</span>
                <i className="fa-solid fa-magnifying-glass"></i>
              </div>

              <div className="icon-btn reload" onClick={reloadData}>
                <span className="tooltip">Reload</span>
                <i className="fa-solid fa-rotate-right"></i>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-light rounded mt-2 container-form-box" style={{ width: "100%" }}>
          <div className="ag-theme-alpine mt-2" style={{ height: 400, width: '100%' }}>
            <AgGridReact
              columnDefs={columnDefs}
              rowData={rowData}
              pagination={true}
              paginationAutoPageSize={true}
              gridOptions={gridOptions}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
export default Input;