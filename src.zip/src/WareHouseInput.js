import React, { useState, useEffect, useRef } from "react";
import "./input.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from "react-router-dom";
import Select from 'react-select'
import { useLocation } from "react-router-dom";
import LoadingScreen from './Loading';
const config = require('./Apiconfig');


function WareHouseInput({ }) {
  const [warehouse_code, setWarehouse_Code] = useState("");
  const [warehouse_name, setWarehouse_Name] = useState("");
  const [status, setStatus] = useState("");
  const [location_no, setLocation_No] = useState("");
  const [statusdrop, setStatusdrop] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [error, setError] = useState(false);
  const [locationnodrop, setLocationdrop] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const StatuS = useRef(null);
  const WarehouseCode = useRef(null);
  const WarehouseName = useRef(null);
  const Status = useRef(null);
  const LocatioN = useRef(null);
  const [hasValueChanged, setHasValueChanged] = useState(false);
  const navigate = useNavigate();
  const created_by = sessionStorage.getItem('selectedUserCode')
  const [loading, setLoading] = useState(false);
  const modified_by = sessionStorage.getItem("selectedUserCode");
  const [isUpdated, setIsUpdated] = useState(false);
  const [isSelectedStatus, setIsSelectStatus] = useState(false);
  const [isSelectedLocation, setIsSelectedLocation] = useState(false);

  const location = useLocation();
  const locationState = location.state || {};
  const mode = locationState.mode || "create"; // ✅ default fallback
  const selectedRow = locationState.selectedRow || null;
  const warehouseCode = location.state?.warehouse_code;
  const company_code = sessionStorage.getItem('selectedCompanyCode');

  useEffect(() => {
    if (!location.state) {
      clearInputFields(); // ensure fresh create mode
    }
  }, []);

  useEffect(() => {
    if (mode === "update" && warehouseCode) {
      fetchWarehouseData();
    }
  }, [mode, warehouseCode]);

  const fetchWarehouseData = async () => {
    try {
      setLoading(true);

      const response = await fetch(`${config.apiBaseUrl}/getWarehouseData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          warehouse_code: warehouseCode,
          company_code
        }),
      });

      const data = await response.json();

      if (response.ok && data.length > 0) {
        const warehouse = data[0];

        setSelectedLocation({
          label: warehouse.location_no,
          value: warehouse.location_no,
        });
        setLocation_No(warehouse.location_no || "");
        setSelectedStatus({
          label: warehouse.status,
          value: warehouse.status,
        });
        setStatus(warehouse.status || "");
        setWarehouse_Code(warehouse.warehouse_code || "");
        setWarehouse_Name(warehouse.warehouse_name || "");
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to fetch warehouse details");
    } finally {
      setLoading(false);
    }
  };

  const clearInputFields = () => {
    setWarehouse_Code("");
    setWarehouse_Name("");
    setSelectedLocation("");
    setSelectedStatus("");
    setStatus("");
    setLocation_No("");
  };

  // useEffect(() => {
  //   if (mode === "update" && selectedRow) {
  //     setSelectedLocation({
  //       label: selectedRow.location_no,
  //       value: selectedRow.location_no,
  //     });
  //     setLocation_No(selectedRow.location_no || "");
  //     setSelectedStatus({
  //       label: selectedRow.status,
  //       value: selectedRow.status,
  //     });
  //     setStatus(selectedRow.status || "");
  //     setWarehouse_Code(selectedRow.warehouse_code || "");
  //     setWarehouse_Name(selectedRow.warehouse_name || "");

  //   } else if (mode === "create") {
  //     clearInputFields();
  //   }
  // }, [mode, selectedRow]);



  useEffect(() => {
    const company_code = sessionStorage.getItem('selectedCompanyCode');

    fetch(`${config.apiBaseUrl}/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ company_code })
    })
      .then((data) => data.json())
      .then((val) => setStatusdrop(val))
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  useEffect(() => {
    fetch(`${config.apiBaseUrl}/locationno`)
      .then((data) => data.json())
      .then((val) => setLocationdrop(val));
  }, []);

  const filteredOptionStatus = Array.isArray(statusdrop)
    ? statusdrop.map((option) => ({
      value: option.attributedetails_name,
      label: option.attributedetails_name,
    }))
    : [];

  const filteredOptionLocation = Array.isArray(locationnodrop)
    ? locationnodrop.map((option) => ({
      value: option.location_no,
      label: option.location_no,
    }))
    : [];

  const handleChangeStatus = (selectedStatus) => {
    setSelectedStatus(selectedStatus);
    setStatus(selectedStatus ? selectedStatus.value : '');

  };

  const handleChangeLocation = (selectedLocation) => {
    setSelectedLocation(selectedLocation);
    setLocation_No(selectedLocation ? selectedLocation.value : '');

  };


  const handleInsert = async () => {
    if (
      !warehouse_code ||
      !warehouse_name ||
      !status ||
      !location_no
    ) {
      setError(true);
      toast.warning("Missing Required Fields");
      return;
    }
    setError(false);
    setLoading(true);

    try {
      const response = await fetch(`${config.apiBaseUrl}/AddWareHousedata`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          company_code: sessionStorage.getItem('selectedCompanyCode'),
          warehouse_code,
          warehouse_name,
          status,
          location_no,
          created_by: sessionStorage.getItem('selectedUserCode')
        }),
      });
      if (response.ok) {
        console.log("Data inserted successfully");
        toast.success("Data inserted successfully", {
          onClose: () => {
            clearInputFields();
            setError(false)
          }
        });
      } else {
        const errorResponse = await response.json();
        console.error(errorResponse.message);
        toast.warning(errorResponse.message);
      }
    } catch (error) {
      console.error("Error inserting data:", error);
      toast.error('Error inserting data: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleNavigate = () => {
    navigate("/Warehouse", {
      state: {
        refreshGrid: true,
        // preservedRowData: location.state?.preservedRowData,
        preservedInputs: location.state?.preservedInputs
      }
    });
  };

  const handleKeyDown = async (e, nextFieldRef, value, hasValueChanged, setHasValueChanged) => {
    if (e.key === 'Enter') {
      if (hasValueChanged) {
        await handleKeyDownStatus(e);
        setHasValueChanged(false);
      }

      if (value) {
        nextFieldRef.current.focus();
      } else {
        e.preventDefault();
      }
    }
  };



  const handleKeyDownStatus = async (e) => {
    if (e.key === 'Enter' && hasValueChanged) { // Only trigger search if the value has changed
      // Trigger the search function
      setHasValueChanged(false); // Reset the flag after search
    }
  };


  const handleUpdate = async () => {
    if (
      !warehouse_code ||
      !warehouse_name ||
      !selectedStatus ||
      !selectedLocation
    ) {
      setError(true);
      toast.warning("Error: Missing required fields");
      return;
    }
    setError(false);
    setLoading(true);

    try {
      const response = await fetch(`${config.apiBaseUrl}/WarehouseUpdates`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          company_code: sessionStorage.getItem('selectedCompanyCode'),
          warehouse_code,
          warehouse_name,
          status: selectedStatus.value,
          location_no: selectedLocation.value,
          created_by,
          modified_by,
        }),
      });
      if (response.ok) {
        console.log("Data Updated successfully");
        toast.success("Data updated successfully", {
          onClose: () => {
            // clearInputFields();
            setError(false)
          }
        });
      } else {
        const errorResponse = await response.json();
        console.error(errorResponse.message);
        toast.warning(errorResponse.message);
      }
    } catch (error) {
      console.error("Error Update data:", error);
      toast.error('Error inserting data: ' + error.message);
    } finally {
      setLoading(false);
    }
  };


  return (
    <div class="container-fluid Topnav-screen ">
      <div className="">
        <div class="">
          {loading && <LoadingScreen />}
          <ToastContainer position="top-right" className="toast-design" theme="colored" />
          <div className="shadow-lg p-1 bg-light rounded main-header-box">
            <div className="header-flex">
              <h1 className="page-title"> {mode === "update" ? 'Update  Warehouse ' : ' Add Warehouse'} </h1>
              <div className="action-wrapper">
                <div className="action-icon delete" onClick={handleNavigate}>
                  <span className="tooltip">Close</span>
                  <i className="fa-solid fa-xmark"></i>
                </div>
              </div>
            </div>
          </div>

          <div className="shadow-lg p-3 bg-light rounded mt-2 container-form-box">
            <div className="row g-3">

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="whcode"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Warehouse Code"
                    value={warehouse_code}
                    maxLength={18}
                    onChange={(e) => setWarehouse_Code(e.target.value)}
                    ref={WarehouseCode}
                    readOnly={mode === "update"}
                    onKeyDown={(e) => handleKeyDown(e, WarehouseName, WarehouseCode)}
                  />
                  <label className={`exp-form-labels ${error && !warehouse_code ? 'text-danger' : ''}`}>Warehouse Code<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div className="inputGroup">
                  <input
                    id="whname"
                    class="exp-input-field form-control"
                    type="text"
                    placeholder=""
                    required title="Please Enter the Warehouse Name"
                    value={warehouse_name}
                    maxLength={250}
                    onChange={(e) => setWarehouse_Name(e.target.value)}
                    ref={WarehouseName}
                    onKeyDown={(e) => handleKeyDown(e, Status, WarehouseName)}
                  />
                  <label className={`exp-form-labels ${error && !warehouse_name ? 'text-danger' : ''}`}>Warehouse Name<span className="text-danger">*</span></label>
                </div>
              </div>

              <div className="col-md-2">
                <div
                  className={`inputGroup selectGroup 
                  ${selectedStatus ? "has-value" : ""} 
                  ${isSelectedStatus ? "is-focused" : ""}`}
                  title="Please Select the Status"
                >
                  <Select
                    id="status"
                    value={selectedStatus}
                    onChange={handleChangeStatus}
                    options={filteredOptionStatus}
                    placeholder=" "
                    onFocus={() => setIsSelectStatus(true)}
                    onBlur={() => setIsSelectStatus(false)}
                    classNamePrefix="react-select"
                    isClearable
                    ref={Status}
                    onKeyDown={(e) => handleKeyDown(e, LocatioN, Status)}
                  />
                  <label className={`floating-label ${error && !status ? 'text-danger' : ''}`}>Status<span className="text-danger">*</span></label>
                </div>
              </div>


              <div className="col-md-2">
                <div
                  className={`inputGroup selectGroup 
                  ${selectedLocation ? "has-value" : ""} 
                  ${isSelectedLocation ? "is-focused" : ""}`}
                  title="Please Select the Location No"
                >
                  <Select
                    id="status"
                    value={selectedLocation}
                    onChange={handleChangeLocation}
                    options={filteredOptionLocation}
                    placeholder=" "
                    onFocus={() => setIsSelectedLocation(true)}
                    onBlur={() => setIsSelectedLocation(false)}
                    classNamePrefix="react-select"
                    isClearable
                    ref={LocatioN}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        if (mode === "create") {
                          handleInsert();
                        } else {
                          handleUpdate();
                        }
                      }
                    }}
                  />
                  <label className={`floating-label ${error && !location_no ? 'text-danger' : ''}`}>Location No<span className="text-danger">*</span></label>
                </div>
              </div>

              <div class="col-12">
                <div className="search-btn-wrapper">
                  {mode === "create" ? (
                    <div className="icon-btn save" onClick={handleInsert}>
                      <span className="tooltip">Save</span>
                      <i class="fa-solid fa-floppy-disk"></i>
                    </div>
                  ) : (
                    <div className="icon-btn update" onClick={handleUpdate}>
                      <span className="tooltip">Update</span>
                      <i class="fa-solid fa-pen-to-square"></i>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
export default WareHouseInput;
