import React, { useState, useEffect, useRef } from "react";
import "./input.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Select from 'react-select'
import AttriHdrInputPopup from "./AttriHdrInput";
import { useLocation } from "react-router-dom";
import LoadingScreen from './Loading';

const config = require('./Apiconfig');

function AttriDetInput({ }) {
  const [open2, setOpen2] = React.useState(false);
  const [attributeheader_code, setAttributeheader_Code] = useState("");
  const [attributedetails_code, setAttributedetails_code] = useState("");
  const [attributedetails_name, setAttributedetails_name] = useState("");
  const [descriptions, setDescriptions] = useState("");
  const navigate = useNavigate();
  const [statusdrop, setCodedrop] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectedHeader, setSelectedHeader] = useState('Cash');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const code = useRef(null);
  const subcode = useRef(null);
  const detailname = useRef(null);
  const description = useRef(null);
  const [hasValueChanged, setHasValueChanged] = useState(false);
  const created_by = sessionStorage.getItem('selectedUserCode')
  const [isSelectCode, setIsSelectCode] = useState(false);

  const modified_by = sessionStorage.getItem("selectedUserCode");
  const [isUpdated, setIsUpdated] = useState(false);

  const location = useLocation();
  const locationState = location.state || {};
  const mode = locationState.mode || "create"; // ✅ default fallback
  const selectedRow = locationState.selectedRow || null;
  const attributeHeaderCode = location.state?.attributeheader_code;
  const attributeDetailsCode = location.state?.attributedetails_code;
  const company_code = sessionStorage.getItem('selectedCompanyCode');

  useEffect(() => {
    if (!location.state) {
      clearInputFields();
    }
  }, []);

  useEffect(() => {
    if (mode === "update" && attributeHeaderCode && attributeDetailsCode) {
      fetchAttributeData();
    }
  }, [mode, attributeHeaderCode, attributeDetailsCode]);

  const fetchAttributeData = async () => {
    try {
      setLoading(true);

      const response = await fetch(`${config.apiBaseUrl}/getAttributeData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          attributeheader_code: attributeHeaderCode,
          attributedetails_code: attributeDetailsCode,
          company_code
        }),
      });

      const data = await response.json();

      if (response.ok && data.length > 0) {
        const attribute = data[0];

        setSelectedHeader({
          label: attribute.attributeheader_code,
          value: attribute.attributeheader_code,
        });
        setAttributeheader_Code(attribute.attributeheader_code || "");
        setAttributedetails_code(attribute.attributedetails_code || "");
        setAttributedetails_name(attribute.attributedetails_name || "");
        setDescriptions(attribute.descriptions || "");
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to fetch attribute details");
    } finally {
      setLoading(false);
    }
  };

  const clearInputFields = () => {
    setSelectedHeader("");
    setAttributeheader_Code("");
    setAttributedetails_code("");
    setAttributedetails_name("");
    setDescriptions("");
  };

  // useEffect(() => {
  //   if (mode === "update" && selectedRow) {
  //     setSelectedHeader({
  //       label: selectedRow.attributeheader_code,
  //       value: selectedRow.attributeheader_code,
  //     });
  //     setAttributeheader_Code(selectedRow.attributeheader_code || "");
  //     setAttributedetails_code(selectedRow.attributedetails_code || "");
  //     setAttributedetails_name(selectedRow.attributedetails_name || "");
  //     setDescriptions(selectedRow.descriptions || "");
  //   } else if (mode === "create") {
  //     clearInputFields();
  //   }
  // }, [mode, selectedRow]);

  // useEffect(() => {
  //   fetch(`${config.apiBaseUrl}/hdrcode`)
  //     .then((data) => data.json())
  //     .then((val) => setCodedrop(val));
  // }, []);

  const fetchHdrCode = () => {
    fetch(`${config.apiBaseUrl}/hdrcode`)
      .then((data) => data.json())
      .then((val) => setCodedrop(val));
  };

  // Page load time la run aagum
  useEffect(() => {
    fetchHdrCode();
  }, []);

  const filteredOptionHeader = Array.isArray(statusdrop)
    ? statusdrop.map((option) => ({
      value: option.attributeheader_code,
      label: option.attributeheader_code,
    }))
    : [];

  const handleChangeHeader = (selectedHeader) => {
    setSelectedHeader(selectedHeader);
    setAttributeheader_Code(selectedHeader ? selectedHeader.value : '');
  };

  const handleInsert = async () => {
    if (!attributeheader_code || !attributedetails_code || !attributedetails_name) {
      setError(true);
      toast.warning("Missing Required Fields");
      return;
    }
    setError(false);
    setLoading(true);

    try {
      const response = await fetch(`${config.apiBaseUrl}/addattridetData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          company_code: sessionStorage.getItem('selectedCompanyCode'),
          attributeheader_code,
          attributedetails_code,
          attributedetails_name,
          descriptions,
          created_by: sessionStorage.getItem('selectedUserCode')
        }),
      });
      if (response.ok) {
        toast.success("Data inserted successfully", {
          onClose: () => {
            clearInputFields();
            setError(false)
          }
        });
      } else {
        const errorResponse = await response.json();
        console.error(errorResponse.message);
        toast.warning(errorResponse.message);
      }
    } catch (error) {
      console.error("Error inserting data:", error);
      toast.error('Error inserting data: ' + error.message);
    }
    finally {
      setLoading(false);
    }
  };

  const handleNavigate = () => {
    navigate("/Attribute", {
      state: {
        refreshGrid: true,
        // preservedRowData: location.state?.preservedRowData,
        preservedInputs: location.state?.preservedInputs
      }
    });
  };

  const handleKeyDown = async (e, nextFieldRef, value, hasValueChanged, setHasValueChanged) => {
    if (e.key === 'Enter') {
      if (hasValueChanged) {
        await handleKeyDownStatus(e);
        setHasValueChanged(false);
      }

      if (value) {
        nextFieldRef.current.focus();
      } else {
        e.preventDefault();
      }
    }
  };

  const handleKeyDownStatus = async (e) => {
    if (e.key === 'Enter' && hasValueChanged) {
      setHasValueChanged(false);
    }
  };

  const handleClickOpen = (params) => {
    setOpen2(true);
    console.log("Opening popup...");
  };
  const handleClose = () => {
    setOpen2(false);
    fetchHdrCode();
  };

  const handleUpdate = async () => {
    if (
      !attributeheader_code ||
      !attributedetails_code ||
      !attributedetails_name ||
      !descriptions

    ) {
      setError(true);
      toast.warning("Missing Required Fields");
      return;
    }
    setError(false);
    setLoading(true);


    try {
      const response = await fetch(`${config.apiBaseUrl}/AttributeUpdate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          attributeheader_code,
          attributedetails_code,
          attributedetails_name,
          descriptions,
          created_by,
          modified_by,
          company_code: sessionStorage.getItem("selectedCompanyCode"),
        }),
      });
      if (response.ok) {
        toast.success("Data updated successfully", {
          onClose: () => {
            // clearInputFields();
            setError(false)
          }
        });
      } else {
        const errorResponse = await response.json();
        console.error(errorResponse.message);
        toast.warning(errorResponse.message);
      }
    } catch (error) {
      console.error("Error Update data:", error);
      toast.error('Error Update data: ' + error.message);
    }
    finally {
      setLoading(false);
    }
  };

  return (
    <div class="container-fluid Topnav-screen ">
      {loading && <LoadingScreen />}
      <ToastContainer position="top-right" className="toast-design" theme="colored" />
      <div className="shadow-lg p-1 bg-light rounded main-header-box">
        <div className="header-flex">
          <h1 className="page-title">{mode === "update" ? 'Update Attribute Details' : 'Add Attribute Details'}</h1>
          <div className="action-wrapper">
            <div className="action-icon delete" onClick={handleNavigate}>
              <span className="tooltip">Close</span>
              <i className="fa-solid fa-xmark"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="shadow-lg p-3 bg-light rounded mt-2 container-form-box">
        <div className="row g-3">

          <div className="col-md-2">
            <div
              className={`inputGroup selectGroup 
              ${selectedHeader ? "has-value" : ""} 
              ${isSelectCode ? "is-focused" : ""}`}
              title="Please Select the Code"
            >
              <Select
                id="HdrCode"
                value={selectedHeader}
                onChange={handleChangeHeader}
                options={filteredOptionHeader}
                placeholder=" "
                onFocus={() => setIsSelectCode(true)}
                onBlur={() => setIsSelectCode(false)}
                classNamePrefix="react-select"
                isClearable
                ref={code}
                readOnly={mode === "update"}
                isDisabled={mode === "update"}
                onKeyDown={(e) => handleKeyDown(e, subcode, code)}
              />

              <label className={`floating-label ${error && !attributeheader_code ? 'text-danger' : ''}`}>Code<span className="text-danger">*</span></label>

              {mode !== "update" && (
                <span
                  type="button"
                  className="select-add-btn"
                  title="Add Header"
                  onClick={handleClickOpen}
                >
                  <i className="fa-solid fa-plus"></i>
                </span>
              )}
            </div>
          </div>

          <div className="col-md-2">
            <div className="inputGroup">
              <input
                id="adcode"
                className="exp-input-field form-control"
                title="Please Enter the Sub Code"
                type="text"
                autoComplete="off"
                placeholder=" "
                required
                value={attributedetails_code}
                onChange={(e) => setAttributedetails_code(e.target.value)}
                maxLength={25}
                ref={subcode}
                readOnly={mode === "update"}
                onKeyDown={(e) => handleKeyDown(e, detailname, subcode)}
              />
              <label className={`exp-form-labels ${error && !attributedetails_code ? 'text-danger' : ''}`}>Sub Code<span className="text-danger">*</span></label>
            </div>
          </div>

          <div className="col-md-2">
            <div className="inputGroup">
              <input
                id="adnames"
                class="exp-input-field form-control"
                title="Please Enter the Detail Name"
                type="text"
                autoComplete="off"
                placeholder=" "
                value={attributedetails_name}
                onChange={(e) => setAttributedetails_name(e.target.value)}
                maxLength={250}
                ref={detailname}
                onKeyDown={(e) => handleKeyDown(e, description, detailname)}
              />
              <label for="rid" className={`exp-form-labels ${error && !attributedetails_name ? 'text-danger' : ''}`}>Detail Name<span className="text-danger">*</span></label>
            </div>
          </div>

          <div className="col-md-2">
            <div className="inputGroup">
              <input
                id="addesc"
                class="exp-input-field form-control"
                type="text"
                placeholder=""
                title="Please Enter the Description"
                value={descriptions}
                onChange={(e) => setDescriptions(e.target.value)}
                maxLength={250}
                ref={description}
                // onKeyDown={(e) => handleKeyDown(e, description)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    if (mode === "create") {
                      handleInsert();
                    } else {
                      handleUpdate();
                    }
                  }
                }}
              />
              <label for="rid" className="exp-form-labels">Description</label>
            </div>
          </div>

          <div class="col-12">
            <div className="search-btn-wrapper">
              {mode === "create" ? (
                <div className="icon-btn save" onClick={handleInsert}>
                  <span className="tooltip">Save</span>
                  <i class="fa-solid fa-floppy-disk"></i>
                </div>
              ) : (
                <div className="icon-btn update" onClick={handleUpdate}>
                  <span className="tooltip">Update</span>
                  <i class="fa-solid fa-pen-to-square"></i>
                </div>
              )}
            </div>
          </div>

          <div>
            <AttriHdrInputPopup open={open2} handleClose={handleClose} />
          </div>

        </div>
      </div>
    </div>
  );
}
export default AttriDetInput;